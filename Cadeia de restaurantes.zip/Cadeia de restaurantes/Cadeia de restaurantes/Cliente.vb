﻿Public Class Cliente
    Private _data As Date = Nothing
    Private _nome As String = ""
    Private _nIF As Integer = 0
    Private _idade As Integer = 0

    Public Property NIF As Integer
        Get
            Return _nIF
        End Get
        Set(value As Integer)
            _nIF = value
        End Set
    End Property

    Public Property Nome As String
        Get
            Return _nome
        End Get
        Set(value As String)
            _nome = value
        End Set
    End Property

    Public Property Data As Date
        Get
            Return _data
        End Get
        Set(value As Date)
            _data = value
        End Set
    End Property

    Public Property Idade As Integer
        Get
            Return _idade
        End Get
        Set(value As Integer)
            _idade = calcular(Data)
        End Set
    End Property

    Public Sub New(ByVal nome As String, ByVal data As Date, ByVal nif As Integer)
        Me.Nome = nome
        Me.Data = data
        Me.NIF = nif
        Idade = calcular(data)
    End Sub


    Public Function calcular(ByVal datanasc As Date)
        Dim Temp As Integer
        Temp = DateDiff(DateInterval.Year, datanasc, Today)

        If datanasc.Month < Today.Month Then
            Temp = Temp - 1
        ElseIf datanasc.Month = Today.Month Then
            If datanasc.Day < Today.Day Then
                Temp = Temp - 1
            End If
        End If

        Return Temp

    End Function

End Class
