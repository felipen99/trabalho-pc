﻿Public Class ClienteVip : Inherits Cliente
    Private _prato As String

    Public Property Prato As String
        Get
            Return _prato
        End Get
        Set(value As String)
            _prato = value
        End Set
    End Property



    Public Sub New(ByVal nome As String, ByVal data As Date, ByVal nif As Integer, ByVal prato As String)
        MyBase.New(nome, data, nif)
        If verificar(prato) Then
            Me.Prato = prato
        End If
    End Sub

    Public Function verificar(ByVal prato As String)
        Dim resultado As Boolean = False
        If UCase(prato) = "ENTRADA" Or UCase(prato) = "PRATO PRINCIPAL" Or UCase(prato) = "SOBREMESA" Then
            resultado = True

        End If

        Return resultado
    End Function

    Public Function AlterarPrato(ByVal prato As String)
        Dim resultado As Boolean = False
        If verificar(prato) Then
            resultado = True
            Me.Prato = prato
        End If
        Return resultado
    End Function
End Class
