﻿Public Class FormPratos

    Public visivel As Integer = 0
    Public ePratoDia As Boolean = False
    Private Sub FormPratos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        mostra()
        Numero.Text = "Restaurante " & Cadeia(visivel2).Nome

    End Sub

    Public Sub mostra()
        If Cadeia(visivel2).Pratos.Count > 0 Then
            If visivel < 0 Then
                visivel = 0
            ElseIf visivel > Cadeia(visivel2).Pratos.Count - 1 Then
                visivel = Cadeia(visivel2).Pratos.Count - 1
            End If

            If visivel = 0 Then
                Botao1.Enabled = False
                Botao2.Enabled = False
                Botao3.Enabled = True
                Botao4.Enabled = True
            ElseIf visivel = Cadeia(visivel2).Pratos.Count - 1 Then
                Botao1.Enabled = True
                Botao2.Enabled = True
                Botao3.Enabled = False
                Botao4.Enabled = False
            Else
                Botao1.Enabled = True
                Botao2.Enabled = True
                Botao3.Enabled = True
                Botao4.Enabled = True
            End If

            If visivel = 0 And Cadeia(visivel2).Pratos.Count = 1 Then
                Botao1.Enabled = False
                Botao2.Enabled = False
                Botao3.Enabled = False
                Botao4.Enabled = False
                RegistarPrato.Visible = True
                RegPratoDia.Visible = True
                Entrada.Enabled = True
                PratoPrincipal.Enabled = True
                Sobremesa.Enabled = True
                NomePrato.Enabled = True
                Almoco.Enabled = True
                Jantar.Enabled = True
                DateTimePicker1.Enabled = True
                Preco.Enabled = True
            End If

            NomePrato.Text = Cadeia(visivel2).Pratos(visivel).Nome
            Preco.Text = Cadeia(visivel2).Pratos(visivel).Preco
            TipoPrato.Text = Cadeia(visivel2).Pratos(visivel).Tipo
            NovoPrecoTB.Text = ""
            Pratos.Text = visivel + 1 & " de " & Cadeia(visivel2).Pratos.Count

            Lista.Items.Clear()
            For k = 0 To Cadeia(visivel2).Ingredientes.Count - 1
                Lista.Items.Add(Cadeia(visivel2).Ingredientes(k).Nome & vbTab & Cadeia(visivel2).Ingredientes(k).Quantidade)

                'ADICIONEI ESTA PARTE POR CAUSA DO ALTERA INGREDIENTES
                For J = 0 To Cadeia(visivel2).Pratos(visivel).Ingredientes.Count - 1
                    If Cadeia(visivel2).Pratos(visivel).Ingredientes(J).Nome = Cadeia(visivel2).Ingredientes(k).Nome Then
                        Lista.SetItemChecked(k, True)
                    End If
                Next
            Next

            ListaPratos.Items.Clear()
            ListaPratosDia.Items.Clear()

            For k = 0 To Cadeia(visivel2).Pratos.Count - 1
                'MARIANA
                If ePratoDia = False Then
                    ListaPratos.Items.Add(Cadeia(visivel2).Pratos(k).Nome)
                ElseIf ePratoDia = True Then
                    ListaPratosDia.Items.Add(Cadeia(visivel2).Pratos(k).Nome)
                End If

            Next
        Else
            inicial()
        End If
    End Sub

    Public Sub inicial()
        RegistarPrato.Visible = False
        Botao1.Enabled = False
        Botao2.Enabled = False
        Botao3.Enabled = False
        Botao4.Enabled = False
        TipoPrato.Enabled = False

    End Sub

    Private Sub CriarPrato_Click(sender As Object, e As EventArgs) Handles CriarPrato.Click
        Dim pratos As Prato
        pratos = New Prato
        Cadeia(visivel2).Pratos.Add(pratos)
        visivel = Cadeia(visivel2).Pratos.Count - 1

        NovoPrecoTB.Enabled = False
        AlterarPreco.Enabled = False

        mostra()
    End Sub

    Private Sub CriarPratoDia_Click(sender As Object, e As EventArgs) Handles CriarPratoDia.Click
        Dim pratodia As PratoDia
        pratodia = New PratoDia
        Cadeia(visivel2).Pratos.Add(pratodia)

        visivel = Cadeia(visivel2).Pratos.Count - 1
        ePratoDia = True

        NovoPrecoTB.Enabled = False
        AlterarPreco.Enabled = False

        mostra()
    End Sub

    Private Sub Botao3_Click(sender As Object, e As EventArgs) Handles Botao3.Click
        visivel = visivel + 1
        mostra()
    End Sub

    Private Sub Botao4_Click(sender As Object, e As EventArgs) Handles Botao4.Click
        visivel = Cadeia(visivel2).Pratos.Count - 1
        mostra()
    End Sub

    Private Sub Botao2_Click(sender As Object, e As EventArgs) Handles Botao2.Click
        visivel = visivel - 1
        mostra()
    End Sub

    Private Sub Botao1_Click(sender As Object, e As EventArgs) Handles Botao1.Click
        visivel = 0
        mostra()
    End Sub

    Private Sub Entrada_Click(sender As Object, e As EventArgs) Handles Entrada.Click
        TipoPrato.Text = "Entrada"

    End Sub

    Private Sub PratoPrincipal_Click(sender As Object, e As EventArgs) Handles PratoPrincipal.Click
        TipoPrato.Text = "Prato Principal"
    End Sub

    Private Sub Sobremesa_Click(sender As Object, e As EventArgs) Handles Sobremesa.Click
        TipoPrato.Text = "Sobremesa"
    End Sub

    Private Sub RegistarPrato_Click(sender As Object, e As EventArgs) Handles RegistarPrato.Click
        Dim temp As Integer
        Dim quantidades As ArrayList
        quantidades = New ArrayList
        Dim ingredientesnec As Ingredientes
        ingredientesnec = New Ingredientes

        If TipoPrato.Text <> "" Then
            For k = 0 To Lista.Items.Count - 1
                If Lista.GetItemChecked(k) = True Then
                    temp = InputBox("Qual é a quantidade necessaria do ingrediente " & Cadeia(visivel2).Ingredientes(k).Nome)
                    quantidades.Add(temp)
                    ingredientesnec.Add(Cadeia(visivel2).Ingredientes(k))
                End If

            Next
        End If
        Cadeia(visivel2).Pratos(visivel).Nome = NomePrato.Text
        Cadeia(visivel2).Pratos(visivel).Tipo = TipoPrato.Text
        Cadeia(visivel2).Pratos(visivel).Ingredientes = ingredientesnec
        Cadeia(visivel2).Pratos(visivel).Quantidades = quantidades
        Cadeia(visivel2).Pratos(visivel).Preco = Val(Preco.Text)

        NovoPrecoTB.Enabled = True
        AlterarPreco.Enabled = True

        mostra()
    End Sub

    Private Sub RegPratoDia_Click(sender As Object, e As EventArgs) Handles RegPratoDia.Click
        Dim temp As Integer
        Dim quantidades As ArrayList
        quantidades = New ArrayList
        Dim ingredientesnec As Ingredientes
        ingredientesnec = New Ingredientes

        If TipoPrato.Text <> "" Then
            For k = 0 To Lista.Items.Count - 1
                If Lista.GetItemChecked(k) = True Then
                    temp = InputBox("Qual é a quantidade necessaria do ingrediente " & Cadeia(visivel2).Ingredientes(k).Nome)
                    quantidades.Add(temp)
                    ingredientesnec.Add(Cadeia(visivel2).Ingredientes(k))
                End If

            Next
        End If

        Cadeia(visivel2).Pratos(visivel).Nome = NomePrato.Text
        Cadeia(visivel2).Pratos(visivel).Tipo = TipoPrato.Text
        Cadeia(visivel2).Pratos(visivel).Ingredientes = ingredientesnec
        Cadeia(visivel2).Pratos(visivel).Quantidades = quantidades
        Cadeia(visivel2).Pratos(visivel).Preco = Val(Preco.Text)

        'MARIANA
        'Cadeia(visivel2).Pratos(visivel).hora = HoraPratoDia.Text
        'Cadeia(visivel2).Pratos(visivel).data = DateTimePicker1.Value

        NovoPrecoTB.Enabled = True
        AlterarPreco.Enabled = True

        mostra()
    End Sub
    'MARIANA
    Private Sub AlterarPreco_Click(sender As Object, e As EventArgs) Handles AlterarPreco.Click

        If NovoPrecoTB.Text > 0 Then
            Cadeia(visivel2).Pratos(visivel).Preco = Val(NovoPrecoTB.Text)
        End If

        mostra()
    End Sub

    Private Sub Almoco_Click(sender As Object, e As EventArgs) Handles Almoco.Click
        HoraPratoDia.Text = "Almoço"
    End Sub

    Private Sub Jantar_Click(sender As Object, e As EventArgs) Handles Jantar.Click
        HoraPratoDia.Text = "Jantar"
    End Sub

    Private Sub AlteraIng_Click(sender As Object, e As EventArgs) Handles AlteraIng.Click
        'VERIFICAR!!!
        Dim Temp As Integer
        Dim quantidades As ArrayList
        quantidades = New ArrayList
        Dim ingredientesnec As Ingredientes
        ingredientesnec = New Ingredientes

        Dim K As Integer = 0
        Dim J As Integer = 0

        While K <= Lista.SelectedItems.Count - 1

            While J <= Cadeia(visivel2).Ingredientes.Count - 1
                If Lista.SelectedItems(K) = Cadeia(visivel2).Ingredientes(J).Nome & vbTab & Cadeia(visivel2).Ingredientes(J).Quantidade Then
                    J = J + 1
                Else
                    Temp = InputBox("Qual é a quantidade necessaria do ingrediente " & '??????)
                    quantidades.Add(Temp)
                    ingredientesnec.Add(Lista.SelectedItems(K))

                    J = J + 1
                End If

            End While

            K = K + 1
        End While


        Dim Encontrou As Boolean = False
        Dim T As Integer = 0

        For K = 0 To Cadeia(visivel2).Pratos(visivel).Ingredientes.Count - 1

            While T <= Lista.SelectedItems.Count And Encontrou = False

                If Cadeia(visivel2).Pratos(visivel).Ingredientes(K).Nome & vbTab & Cadeia(visivel2).Pratos(visivel).Ingredientes(K).Quantidade = Lista.SelectedItems(T) Then
                    Encontrou = True

                End If

                T = T + 1
            End While

            If Encontrou = False Then
                ingredientesnec.Remove(Cadeia(visivel2).Ingredientes(K))
            End If

        Next

        mostra()

    End Sub
End Class