﻿Public Class FormIngredientes
    Dim visivel As Integer = 0
    Private Sub FormIngredientes_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        mostra()
        Numero.Text = "Restaurante " & Cadeia(visivel2).Nome
    End Sub

    Public Sub inicial()

        Button6.Enabled = False
        Button7.Enabled = False
        Button5.Enabled = False
        Button8.Enabled = False
        Button3.Visible = False
        Button2.Visible = False
        Button4.Visible = False
        Button9.Visible = False
        AdicionarRemover.Visible = False
        Label4.Visible = False
        Nome.Enabled = False
        Precoo.Enabled = False
        Quantidadee.Enabled = False

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        visivel = visivel + 1
        mostra()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        visivel = Cadeia(visivel2).Ingredientes.Count - 1
        mostra()
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        visivel = visivel - 1
        mostra()
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        visivel = 0
        mostra()
    End Sub

    Public Sub mostra()
        If Cadeia(visivel2).Ingredientes.Count > 0 Then
            If visivel < 0 Then
                visivel = 0
            ElseIf visivel > Cadeia(visivel2).Ingredientes.Count - 1 Then
                visivel = Cadeia(visivel2).Ingredientes.Count - 1
            End If

            If visivel = 0 Then
                Button5.Enabled = True
                Button6.Enabled = True
                Button7.Enabled = False
                Button8.Enabled = False
            ElseIf visivel = Cadeia(visivel2).Ingredientes.Count - 1 Then
                Button7.Enabled = True
                Button8.Enabled = True
                Button5.Enabled = False
                Button6.Enabled = False

            Else
                Button5.Enabled = True
                Button6.Enabled = True
                Button7.Enabled = True
                Button8.Enabled = True
            End If

            If visivel = 0 And Cadeia(visivel2).Ingredientes.Count = 1 Then
                Button5.Enabled = False
                Button6.Enabled = False
                Button7.Enabled = False
                Button8.Enabled = False
                Button2.Visible = True
                Button3.Visible = True
                Button4.Visible = True
                Button9.Visible = True
                AdicionarRemover.Visible = True
                Label4.Visible = True
                Nome.Enabled = True
                Precoo.Enabled = True
                Quantidadee.Enabled = True
            End If

            Nome.Text = Cadeia(visivel2).Ingredientes(visivel).Nome
            Precoo.Text = Cadeia(visivel2).Ingredientes(visivel).Custouni
            Quantidadee.Text = Cadeia(visivel2).Ingredientes(visivel).Quantidade


            Ing.Text = visivel + 1 & " de " & Cadeia(visivel2).Ingredientes.Count



            GridIng.Columns.Clear()

            GridIng.ColumnCount = 3

            GridIng.RowCount = Cadeia(visivel2).Ingredientes.Count

            Dim i As Integer = 0

            For Each column As DataGridViewColumn In GridIng.Columns
                If i = 0 Then
                    column.HeaderText = "Lista Ingredientes"
                ElseIf i = 1 Then
                    column.HeaderText = "Custo Unidade"
                ElseIf i = 2 Then
                    column.HeaderText = "Quantidade"
                End If
                i = i + 1
            Next




            For k = 0 To Cadeia(visivel2).Ingredientes.Count - 1

                GridIng.Item(0, k).Value = Cadeia(visivel2).Ingredientes(k).Nome
                GridIng.Item(1, k).Value = Cadeia(visivel2).Ingredientes(k).Custouni
                GridIng.Item(2, k).Value = Cadeia(visivel2).Ingredientes(k).Quantidade
            Next

        Else
            inicial()
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim ingrediente As Ingrediente
        ingrediente = New Ingrediente
        Cadeia(visivel2).Ingredientes.Add(ingrediente)
        visivel = Cadeia(visivel2).Ingredientes.Count - 1
        Me.Nome.Focus()
        mostra()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Cadeia(visivel2).Ingredientes(visivel).Nome = Nome.Text
        Cadeia(visivel2).Ingredientes(visivel).Custouni = Val(Precoo.Text)
        Cadeia(visivel2).Ingredientes(visivel).Quantidade = Val(Quantidadee.Text)
        mostra()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Cadeia(visivel2).Ingredientes(visivel).Quantidade = Cadeia(visivel2).Ingredientes(visivel).Quantidade + AdicionarRemover.Text
        mostra()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Cadeia(visivel2).Ingredientes(visivel).Quantidade = Cadeia(visivel2).Ingredientes(visivel).Quantidade - AdicionarRemover.Text
        mostra()
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Dim resultado As Boolean = False
        Dim k As Integer
        k = 0
        While k <= Cadeia(visivel2).Ingredientes.Count - 1 And Not resultado
            If Cadeia(visivel2).Ingredientes(k).Nome = Nome.Text And Nome.Text <> "Ingrediente" Then
                resultado = True
                Cadeia(visivel2).Ingredientes.RemoveAt(k)
                visivel = visivel - 1
                mostra()
                k = k + 1
            End If
        End While




        If Not resultado Then
            MsgBox("O Ingrediente Não Existe")
        End If
    End Sub
End Class