﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormPratos
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.ListaPratos = New System.Windows.Forms.ListBox()
        Me.Lista = New System.Windows.Forms.CheckedListBox()
        Me.Numero = New System.Windows.Forms.Label()
        Me.Botao4 = New System.Windows.Forms.Button()
        Me.Botao3 = New System.Windows.Forms.Button()
        Me.Botao2 = New System.Windows.Forms.Button()
        Me.Pratos = New System.Windows.Forms.Label()
        Me.NomePrato = New System.Windows.Forms.TextBox()
        Me.Preco = New System.Windows.Forms.TextBox()
        Me.Nome = New System.Windows.Forms.Label()
        Me.PrecoPrato = New System.Windows.Forms.Label()
        Me.Botao1 = New System.Windows.Forms.Button()
        Me.Entrada = New System.Windows.Forms.Button()
        Me.Sobremesa = New System.Windows.Forms.Button()
        Me.PratoPrincipal = New System.Windows.Forms.Button()
        Me.TipoPrato = New System.Windows.Forms.TextBox()
        Me.CriarPrato = New System.Windows.Forms.Button()
        Me.RegistarPrato = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'ListaPratos
        '
        Me.ListaPratos.FormattingEnabled = True
        Me.ListaPratos.Location = New System.Drawing.Point(592, 74)
        Me.ListaPratos.Name = "ListaPratos"
        Me.ListaPratos.Size = New System.Drawing.Size(150, 433)
        Me.ListaPratos.TabIndex = 0
        '
        'Lista
        '
        Me.Lista.FormattingEnabled = True
        Me.Lista.Location = New System.Drawing.Point(109, 299)
        Me.Lista.Name = "Lista"
        Me.Lista.Size = New System.Drawing.Size(377, 229)
        Me.Lista.TabIndex = 1
        '
        'Numero
        '
        Me.Numero.AutoSize = True
        Me.Numero.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Numero.Location = New System.Drawing.Point(562, 26)
        Me.Numero.Name = "Numero"
        Me.Numero.Size = New System.Drawing.Size(150, 16)
        Me.Numero.TabIndex = 30
        Me.Numero.Text = "Restaurante Numero"
        '
        'Botao4
        '
        Me.Botao4.Location = New System.Drawing.Point(316, 26)
        Me.Botao4.Name = "Botao4"
        Me.Botao4.Size = New System.Drawing.Size(45, 23)
        Me.Botao4.TabIndex = 32
        Me.Botao4.Text = ">>"
        Me.Botao4.UseVisualStyleBackColor = True
        '
        'Botao3
        '
        Me.Botao3.Location = New System.Drawing.Point(265, 26)
        Me.Botao3.Name = "Botao3"
        Me.Botao3.Size = New System.Drawing.Size(45, 23)
        Me.Botao3.TabIndex = 33
        Me.Botao3.Text = ">"
        Me.Botao3.UseVisualStyleBackColor = True
        '
        'Botao2
        '
        Me.Botao2.Location = New System.Drawing.Point(160, 26)
        Me.Botao2.Name = "Botao2"
        Me.Botao2.Size = New System.Drawing.Size(45, 23)
        Me.Botao2.TabIndex = 34
        Me.Botao2.Text = "<"
        Me.Botao2.UseVisualStyleBackColor = True
        '
        'Pratos
        '
        Me.Pratos.AutoSize = True
        Me.Pratos.Location = New System.Drawing.Point(213, 31)
        Me.Pratos.Name = "Pratos"
        Me.Pratos.Size = New System.Drawing.Size(37, 13)
        Me.Pratos.TabIndex = 35
        Me.Pratos.Text = "0 de 0"
        '
        'NomePrato
        '
        Me.NomePrato.Location = New System.Drawing.Point(160, 106)
        Me.NomePrato.Name = "NomePrato"
        Me.NomePrato.Size = New System.Drawing.Size(100, 20)
        Me.NomePrato.TabIndex = 36
        '
        'Preco
        '
        Me.Preco.Location = New System.Drawing.Point(160, 143)
        Me.Preco.Name = "Preco"
        Me.Preco.Size = New System.Drawing.Size(100, 20)
        Me.Preco.TabIndex = 37
        '
        'Nome
        '
        Me.Nome.AutoSize = True
        Me.Nome.Location = New System.Drawing.Point(106, 109)
        Me.Nome.Name = "Nome"
        Me.Nome.Size = New System.Drawing.Size(35, 13)
        Me.Nome.TabIndex = 38
        Me.Nome.Text = "Nome"
        '
        'PrecoPrato
        '
        Me.PrecoPrato.AutoSize = True
        Me.PrecoPrato.Location = New System.Drawing.Point(106, 146)
        Me.PrecoPrato.Name = "PrecoPrato"
        Me.PrecoPrato.Size = New System.Drawing.Size(35, 13)
        Me.PrecoPrato.TabIndex = 39
        Me.PrecoPrato.Text = "Preço"
        '
        'Botao1
        '
        Me.Botao1.Location = New System.Drawing.Point(109, 26)
        Me.Botao1.Name = "Botao1"
        Me.Botao1.Size = New System.Drawing.Size(45, 23)
        Me.Botao1.TabIndex = 40
        Me.Botao1.Text = "<<"
        Me.Botao1.UseVisualStyleBackColor = True
        '
        'Entrada
        '
        Me.Entrada.Location = New System.Drawing.Point(70, 180)
        Me.Entrada.Name = "Entrada"
        Me.Entrada.Size = New System.Drawing.Size(87, 23)
        Me.Entrada.TabIndex = 41
        Me.Entrada.Text = "Entrada"
        Me.Entrada.UseVisualStyleBackColor = True
        '
        'Sobremesa
        '
        Me.Sobremesa.Location = New System.Drawing.Point(256, 180)
        Me.Sobremesa.Name = "Sobremesa"
        Me.Sobremesa.Size = New System.Drawing.Size(87, 23)
        Me.Sobremesa.TabIndex = 42
        Me.Sobremesa.Text = "Sobremesa"
        Me.Sobremesa.UseVisualStyleBackColor = True
        '
        'PratoPrincipal
        '
        Me.PratoPrincipal.Location = New System.Drawing.Point(163, 180)
        Me.PratoPrincipal.Name = "PratoPrincipal"
        Me.PratoPrincipal.Size = New System.Drawing.Size(87, 23)
        Me.PratoPrincipal.TabIndex = 43
        Me.PratoPrincipal.Text = "PratoPrincipal"
        Me.PratoPrincipal.UseVisualStyleBackColor = True
        '
        'TipoPrato
        '
        Me.TipoPrato.Location = New System.Drawing.Point(160, 231)
        Me.TipoPrato.Name = "TipoPrato"
        Me.TipoPrato.Size = New System.Drawing.Size(100, 20)
        Me.TipoPrato.TabIndex = 44
        Me.TipoPrato.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'CriarPrato
        '
        Me.CriarPrato.Location = New System.Drawing.Point(374, 81)
        Me.CriarPrato.Name = "CriarPrato"
        Me.CriarPrato.Size = New System.Drawing.Size(112, 69)
        Me.CriarPrato.TabIndex = 45
        Me.CriarPrato.Text = "Criar Prato"
        Me.CriarPrato.UseVisualStyleBackColor = True
        '
        'RegistarPrato
        '
        Me.RegistarPrato.Location = New System.Drawing.Point(374, 182)
        Me.RegistarPrato.Name = "RegistarPrato"
        Me.RegistarPrato.Size = New System.Drawing.Size(112, 69)
        Me.RegistarPrato.TabIndex = 46
        Me.RegistarPrato.Text = "Registar Prato"
        Me.RegistarPrato.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(109, 274)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(234, 13)
        Me.Label1.TabIndex = 47
        Me.Label1.Text = "Nome e Quantidade Respetiva dos Ingredientes"
        '
        'FormPratos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 540)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.RegistarPrato)
        Me.Controls.Add(Me.CriarPrato)
        Me.Controls.Add(Me.TipoPrato)
        Me.Controls.Add(Me.PratoPrincipal)
        Me.Controls.Add(Me.Sobremesa)
        Me.Controls.Add(Me.Entrada)
        Me.Controls.Add(Me.Botao1)
        Me.Controls.Add(Me.PrecoPrato)
        Me.Controls.Add(Me.Nome)
        Me.Controls.Add(Me.Preco)
        Me.Controls.Add(Me.NomePrato)
        Me.Controls.Add(Me.Pratos)
        Me.Controls.Add(Me.Botao2)
        Me.Controls.Add(Me.Botao3)
        Me.Controls.Add(Me.Botao4)
        Me.Controls.Add(Me.Numero)
        Me.Controls.Add(Me.Lista)
        Me.Controls.Add(Me.ListaPratos)
        Me.Name = "FormPratos"
        Me.Text = "FormPratos"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ListaPratos As ListBox
    Friend WithEvents Lista As CheckedListBox
    Friend WithEvents Numero As Label
    Friend WithEvents Botao4 As Button
    Friend WithEvents Botao3 As Button
    Friend WithEvents Botao2 As Button
    Friend WithEvents Pratos As Label
    Friend WithEvents NomePrato As TextBox
    Friend WithEvents Preco As TextBox
    Friend WithEvents Nome As Label
    Friend WithEvents PrecoPrato As Label
    Friend WithEvents Botao1 As Button
    Friend WithEvents Entrada As Button
    Friend WithEvents Sobremesa As Button
    Friend WithEvents PratoPrincipal As Button
    Friend WithEvents TipoPrato As TextBox
    Friend WithEvents CriarPrato As Button
    Friend WithEvents RegistarPrato As Button
    Friend WithEvents Label1 As Label
End Class
