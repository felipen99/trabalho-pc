﻿Public Class PratoDias
    Inherits Collections.CollectionBase

    Public Sub Add(ByVal NewPratoDia As PratoDia)
        Me.List.Add(NewPratoDia)
    End Sub

    Public Sub Remove(ByVal oldPratoDia As PratoDia)
        Me.List.Remove(oldPratoDia)
    End Sub

    Default Public Property item(ByVal index As Integer) As PratoDia
        Get
            Return Me.List.Item(index)
        End Get
        Set(ByVal value As PratoDia)
            Me.List.Item(index) = value
        End Set
    End Property

    Public Shadows Sub clear()
        MyBase.Clear()
    End Sub

    Public Shadows Sub RemoveAt(ByVal index As Integer)
        Remove(item(index))
    End Sub
    Public Sub InsertAt(ByVal index As Integer, ByVal NewPratoDia As PratoDia)
        Me.List.Insert(index, NewPratoDia)
    End Sub

End Class
