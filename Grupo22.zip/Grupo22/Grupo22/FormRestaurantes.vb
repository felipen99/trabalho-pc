﻿Public Class FormRestaurantes

    Public Event fechar()
    Private Sub FormRestaurantes_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        inicial()

        mostra()
        Numero.Text = "Restaurante " & Cadeia(visivel2).Nome
    End Sub

    Private Sub FormRestaurantes_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        RaiseEvent fechar()
    End Sub

    Private Sub ProcurarCliente_Click(sender As Object, e As EventArgs) Handles ProcurarCliente.Click
        Dim encontrado As Boolean = False
        For k = 0 To Cadeia.Clientes.Count - 1
            If Cadeia.Clientes(k).NIF = NIF.Text Then
                encontrado = True
                NomeCliente.Text = Cadeia.Clientes(k).Nome
                DataNascimento.Value = Cadeia.Clientes(k).DataNascimento
            End If
        Next
    End Sub

    Public Sub mostra()
        If Cadeia.Count > 0 Then
            If visivel2 < 0 Then
                visivel2 = 0
            ElseIf visivel2 > Cadeia.Count - 1 Then
                visivel2 = Cadeia.Count - 1
            End If
            Label3.Text = visivel2 + 1 & " de " & Cadeia.Count
        Else
            Inicial
        End If





    End Sub

    Private Sub Botao1_Click(sender As Object, e As EventArgs) Handles Botao1.Click
        visivel2 = 0
        mostra()
    End Sub

    Private Sub Botao2_Click(sender As Object, e As EventArgs) Handles Botao2.Click
        visivel2 = visivel2 - 1
        mostra()
    End Sub

    Private Sub Botao3_Click(sender As Object, e As EventArgs) Handles Botao3.Click
        visivel2 = visivel2 + 1
        mostra()
    End Sub

    Private Sub Botao4_Click(sender As Object, e As EventArgs) Handles Botao4.Click
        visivel2 = Cadeia.Count - 1
        mostra()
    End Sub

    Public Sub inicial()
        NomeCliente.Enabled = False
        DataNascimento.Enabled = False

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Cadeia.ler()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Cadeia.gravar()
    End Sub
End Class