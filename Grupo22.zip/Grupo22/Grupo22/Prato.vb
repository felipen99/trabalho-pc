﻿Imports Grupo22

Public Class Prato
    Private _ingredientes As Ingredientes
    Private _preco As Single = 0
    Private _tipo As String = ""
    Private _nome As String = ""
    Private _quantidades As ArrayList

    Public Property Ingredientes As Ingredientes
        Get
            Return _ingredientes
        End Get
        Set(value As Ingredientes)
            _ingredientes = value
        End Set
    End Property

    Public Property Preco As Single
        Get
            Return _preco
        End Get
        Set(value As Single)
            If value > 0 Then
                _preco = value
            End If

        End Set
    End Property

    Public Property Tipo As String
        Get
            Return _tipo
        End Get
        Set(value As String)
            _tipo = value
        End Set
    End Property

    Public Property Nome As String
        Get
            Return _nome
        End Get
        Set(value As String)
            _nome = value
        End Set
    End Property

    Public Property Quantidades As ArrayList
        Get
            Return _quantidades
        End Get
        Set(value As ArrayList)
            _quantidades = value
        End Set
    End Property

    Public Sub New()
        Me.Ingredientes = New Ingredientes
        Me.Quantidades = New ArrayList
    End Sub
    Public Sub New(ByVal ingredintes As Ingredientes, ByVal Preco As Single, ByVal quantidades As ArrayList,
                   ByVal Tipo As String, ByVal nome As String)
        Me.Ingredientes = New Ingredientes
        Me.Ingredientes = Ingredientes
        If Preco > 0 Then
            Me.Preco = Preco
        End If
        If UCase(Tipo) = "ENTRADA" Or UCase(Tipo) = "PRATO PRINCIPAL" Or UCase(Tipo) = "SOBREMESA" Then
            Me.Tipo = Tipo
        End If
        Me.Nome = nome
    End Sub

    Public Function AlterarPreco(ByVal preco As Single)
        Dim resultado As Boolean = False
        If preco > 0 Then
            resultado = True
            Me.Preco = preco
        End If

        Return resultado

    End Function

    Public Function AlterarIngrediente(ByVal ingrediente As Ingrediente, ByVal subsituto As Ingrediente)
        Dim resultado As Boolean = False
        For k = 0 To Me.Ingredientes.Count - 1
            If ingrediente.Nome = Me._ingredientes(k).Nome Then
                Me.Ingredientes(k) = subsituto
            End If
        Next

        Return resultado
    End Function
End Class
