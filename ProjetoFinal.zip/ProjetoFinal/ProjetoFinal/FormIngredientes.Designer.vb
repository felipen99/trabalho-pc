﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormIngredientes
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.GridIng = New System.Windows.Forms.DataGridView()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Precoo = New System.Windows.Forms.TextBox()
        Me.Nome = New System.Windows.Forms.TextBox()
        Me.Quantidadee = New System.Windows.Forms.TextBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.AdicionarRemover = New System.Windows.Forms.TextBox()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Ing = New System.Windows.Forms.Label()
        Me.Numero = New System.Windows.Forms.TextBox()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.FlowLayoutPanel1.SuspendLayout()
        CType(Me.GridIng, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Controls.Add(Me.GridIng)
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(246, 210)
        Me.FlowLayoutPanel1.Margin = New System.Windows.Forms.Padding(2)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(370, 231)
        Me.FlowLayoutPanel1.TabIndex = 82
        '
        'GridIng
        '
        Me.GridIng.AllowUserToAddRows = False
        Me.GridIng.AllowUserToDeleteRows = False
        Me.GridIng.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.GridIng.Location = New System.Drawing.Point(3, 3)
        Me.GridIng.Name = "GridIng"
        Me.GridIng.ReadOnly = True
        Me.GridIng.Size = New System.Drawing.Size(357, 219)
        Me.GridIng.TabIndex = 27
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 6
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 131.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 197.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 123.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.Label1, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Label3, 0, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.Label2, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.Button1, 2, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Precoo, 1, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.Nome, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Quantidadee, 1, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.Button3, 5, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.Button4, 2, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.Label4, 3, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.AdicionarRemover, 4, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.Button2, 5, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Button9, 2, 2)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(48, 72)
        Me.TableLayoutPanel2.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 2
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(705, 134)
        Me.TableLayoutPanel2.TabIndex = 81
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(3, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(35, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Nome"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(3, 88)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(62, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Quantidade"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(3, 47)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(78, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Preço/unidade"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(218, 3)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(90, 41)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "Criar Ingrediente"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Precoo
        '
        Me.Precoo.Location = New System.Drawing.Point(87, 50)
        Me.Precoo.Name = "Precoo"
        Me.Precoo.Size = New System.Drawing.Size(100, 20)
        Me.Precoo.TabIndex = 1
        '
        'Nome
        '
        Me.Nome.Location = New System.Drawing.Point(87, 3)
        Me.Nome.Name = "Nome"
        Me.Nome.Size = New System.Drawing.Size(100, 20)
        Me.Nome.TabIndex = 0
        '
        'Quantidadee
        '
        Me.Quantidadee.Location = New System.Drawing.Point(87, 91)
        Me.Quantidadee.Name = "Quantidadee"
        Me.Quantidadee.Size = New System.Drawing.Size(100, 20)
        Me.Quantidadee.TabIndex = 8
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(608, 91)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(90, 41)
        Me.Button3.TabIndex = 9
        Me.Button3.Text = "Remover Quantidade"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(218, 50)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(90, 35)
        Me.Button4.TabIndex = 12
        Me.Button4.Text = "Registar ingrediente"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(415, 47)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(62, 13)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Quantidade"
        '
        'AdicionarRemover
        '
        Me.AdicionarRemover.Location = New System.Drawing.Point(485, 50)
        Me.AdicionarRemover.Name = "AdicionarRemover"
        Me.AdicionarRemover.Size = New System.Drawing.Size(93, 20)
        Me.AdicionarRemover.TabIndex = 11
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(218, 91)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(90, 37)
        Me.Button9.TabIndex = 22
        Me.Button9.Text = "Remover ingrediente"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(608, 3)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(90, 41)
        Me.Button2.TabIndex = 7
        Me.Button2.Text = "Adicionar Quantidade"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 8
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 74.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Numero, 6, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Button11, 5, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Button10, 7, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(466, 10)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(287, 48)
        Me.TableLayoutPanel1.TabIndex = 80
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(48, 17)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(45, 23)
        Me.Button7.TabIndex = 16
        Me.Button7.Text = "<<"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(99, 17)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(45, 23)
        Me.Button8.TabIndex = 17
        Me.Button8.Text = "<"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Ing
        '
        Me.Ing.AutoSize = True
        Me.Ing.Location = New System.Drawing.Point(153, 22)
        Me.Ing.Name = "Ing"
        Me.Ing.Size = New System.Drawing.Size(37, 13)
        Me.Ing.TabIndex = 18
        Me.Ing.Text = "0 de 0"
        '
        'Numero
        '
        Me.Numero.Location = New System.Drawing.Point(48, 3)
        Me.Numero.Name = "Numero"
        Me.Numero.Size = New System.Drawing.Size(180, 20)
        Me.Numero.TabIndex = 74
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(247, 17)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(45, 23)
        Me.Button6.TabIndex = 14
        Me.Button6.Text = ">>"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(3, 3)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(39, 23)
        Me.Button11.TabIndex = 76
        Me.Button11.Text = "<"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(234, 3)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(45, 23)
        Me.Button10.TabIndex = 75
        Me.Button10.Text = ">"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(196, 17)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(45, 23)
        Me.Button5.TabIndex = 15
        Me.Button5.Text = ">"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'FormIngredientes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.FlowLayoutPanel1)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.TableLayoutPanel2)
        Me.Controls.Add(Me.Ing)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Name = "FormIngredientes"
        Me.Text = "FormIngredientes"
        Me.FlowLayoutPanel1.ResumeLayout(False)
        CType(Me.GridIng, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents GridIng As DataGridView
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents Label1 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Precoo As TextBox
    Friend WithEvents Nome As TextBox
    Friend WithEvents Quantidadee As TextBox
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents AdicionarRemover As TextBox
    Friend WithEvents Button9 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Ing As Label
    Friend WithEvents Numero As TextBox
    Friend WithEvents Button6 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button5 As Button
End Class
