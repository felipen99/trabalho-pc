﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormReserva
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Botao2 = New System.Windows.Forms.Button()
        Me.Botao1 = New System.Windows.Forms.Button()
        Me.Botao3 = New System.Windows.Forms.Button()
        Me.Botao4 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ReceitaTotal = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.CustoTotal = New System.Windows.Forms.TextBox()
        Me.FlowLayoutPanel3 = New System.Windows.Forms.FlowLayoutPanel()
        Me.GridPratos = New System.Windows.Forms.DataGridView()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.CheckedListBox4 = New System.Windows.Forms.CheckedListBox()
        Me.CheckedListBox3 = New System.Windows.Forms.CheckedListBox()
        Me.CheckedListBox2 = New System.Windows.Forms.CheckedListBox()
        Me.CheckedListBox1 = New System.Windows.Forms.CheckedListBox()
        Me.FlowLayoutPanel2 = New System.Windows.Forms.FlowLayoutPanel()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Nome = New System.Windows.Forms.Label()
        Me.ProcurarCliente = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.NomeCliente = New System.Windows.Forms.TextBox()
        Me.NIF = New System.Windows.Forms.TextBox()
        Me.FazerReserva = New System.Windows.Forms.Button()
        Me.DataNascimento = New System.Windows.Forms.DateTimePicker()
        Me.DataReserva = New System.Windows.Forms.DateTimePicker()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.Numero = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel3.SuspendLayout()
        CType(Me.GridPratos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Botao2
        '
        Me.Botao2.Location = New System.Drawing.Point(356, 13)
        Me.Botao2.Name = "Botao2"
        Me.Botao2.Size = New System.Drawing.Size(45, 23)
        Me.Botao2.TabIndex = 18
        Me.Botao2.Text = "<"
        Me.Botao2.UseVisualStyleBackColor = True
        '
        'Botao1
        '
        Me.Botao1.Location = New System.Drawing.Point(305, 13)
        Me.Botao1.Name = "Botao1"
        Me.Botao1.Size = New System.Drawing.Size(45, 23)
        Me.Botao1.TabIndex = 17
        Me.Botao1.Text = "<<"
        Me.Botao1.UseVisualStyleBackColor = True
        '
        'Botao3
        '
        Me.Botao3.Location = New System.Drawing.Point(671, 12)
        Me.Botao3.Name = "Botao3"
        Me.Botao3.Size = New System.Drawing.Size(45, 23)
        Me.Botao3.TabIndex = 16
        Me.Botao3.Text = ">"
        Me.Botao3.UseVisualStyleBackColor = True
        '
        'Botao4
        '
        Me.Botao4.Location = New System.Drawing.Point(722, 12)
        Me.Botao4.Name = "Botao4"
        Me.Botao4.Size = New System.Drawing.Size(45, 23)
        Me.Botao4.TabIndex = 15
        Me.Botao4.Text = ">>"
        Me.Botao4.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(116, 3)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(639, 20)
        Me.TextBox1.TabIndex = 42
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(3, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(71, 13)
        Me.Label5.TabIndex = 45
        Me.Label5.Text = "Receita Total"
        '
        'ReceitaTotal
        '
        Me.ReceitaTotal.Location = New System.Drawing.Point(192, 3)
        Me.ReceitaTotal.Name = "ReceitaTotal"
        Me.ReceitaTotal.Size = New System.Drawing.Size(183, 20)
        Me.ReceitaTotal.TabIndex = 44
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(381, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(77, 13)
        Me.Label8.TabIndex = 35
        Me.Label8.Text = " Total Reserva"
        '
        'CustoTotal
        '
        Me.CustoTotal.Location = New System.Drawing.Point(570, 3)
        Me.CustoTotal.Name = "CustoTotal"
        Me.CustoTotal.Size = New System.Drawing.Size(185, 20)
        Me.CustoTotal.TabIndex = 34
        '
        'FlowLayoutPanel3
        '
        Me.FlowLayoutPanel3.Controls.Add(Me.GridPratos)
        Me.FlowLayoutPanel3.Location = New System.Drawing.Point(536, 54)
        Me.FlowLayoutPanel3.Margin = New System.Windows.Forms.Padding(2)
        Me.FlowLayoutPanel3.Name = "FlowLayoutPanel3"
        Me.FlowLayoutPanel3.Size = New System.Drawing.Size(465, 188)
        Me.FlowLayoutPanel3.TabIndex = 54
        '
        'GridPratos
        '
        Me.GridPratos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.GridPratos.Location = New System.Drawing.Point(3, 3)
        Me.GridPratos.Name = "GridPratos"
        Me.GridPratos.Size = New System.Drawing.Size(441, 183)
        Me.GridPratos.TabIndex = 41
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckedListBox1)
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckedListBox2)
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckedListBox3)
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckedListBox4)
        Me.FlowLayoutPanel1.Controls.Add(Me.FlowLayoutPanel2)
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(26, 270)
        Me.FlowLayoutPanel1.Margin = New System.Windows.Forms.Padding(2)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(758, 266)
        Me.FlowLayoutPanel1.TabIndex = 53
        '
        'CheckedListBox4
        '
        Me.CheckedListBox4.FormattingEnabled = True
        Me.CheckedListBox4.Location = New System.Drawing.Point(561, 3)
        Me.CheckedListBox4.Name = "CheckedListBox4"
        Me.CheckedListBox4.Size = New System.Drawing.Size(180, 244)
        Me.CheckedListBox4.TabIndex = 46
        '
        'CheckedListBox3
        '
        Me.CheckedListBox3.FormattingEnabled = True
        Me.CheckedListBox3.Location = New System.Drawing.Point(375, 3)
        Me.CheckedListBox3.Name = "CheckedListBox3"
        Me.CheckedListBox3.Size = New System.Drawing.Size(180, 244)
        Me.CheckedListBox3.TabIndex = 40
        '
        'CheckedListBox2
        '
        Me.CheckedListBox2.FormattingEnabled = True
        Me.CheckedListBox2.Location = New System.Drawing.Point(189, 3)
        Me.CheckedListBox2.Name = "CheckedListBox2"
        Me.CheckedListBox2.Size = New System.Drawing.Size(180, 244)
        Me.CheckedListBox2.TabIndex = 39
        '
        'CheckedListBox1
        '
        Me.CheckedListBox1.FormattingEnabled = True
        Me.CheckedListBox1.Location = New System.Drawing.Point(3, 3)
        Me.CheckedListBox1.Name = "CheckedListBox1"
        Me.CheckedListBox1.Size = New System.Drawing.Size(180, 244)
        Me.CheckedListBox1.TabIndex = 38
        '
        'FlowLayoutPanel2
        '
        Me.FlowLayoutPanel2.Location = New System.Drawing.Point(2, 252)
        Me.FlowLayoutPanel2.Margin = New System.Windows.Forms.Padding(2)
        Me.FlowLayoutPanel2.Name = "FlowLayoutPanel2"
        Me.FlowLayoutPanel2.Size = New System.Drawing.Size(150, 81)
        Me.FlowLayoutPanel2.TabIndex = 47
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 3
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 95.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 273.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 125.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Nome, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.ProcurarCliente, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label1, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label7, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.NomeCliente, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.FazerReserva, 2, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.DataNascimento, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.DataReserva, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.NIF, 1, 2)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(26, 54)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 67.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(493, 165)
        Me.TableLayoutPanel1.TabIndex = 52
        '
        'Nome
        '
        Me.Nome.AutoSize = True
        Me.Nome.Location = New System.Drawing.Point(3, 0)
        Me.Nome.Name = "Nome"
        Me.Nome.Size = New System.Drawing.Size(35, 13)
        Me.Nome.TabIndex = 4
        Me.Nome.Text = "Nome"
        '
        'ProcurarCliente
        '
        Me.ProcurarCliente.Location = New System.Drawing.Point(371, 39)
        Me.ProcurarCliente.Name = "ProcurarCliente"
        Me.ProcurarCliente.Size = New System.Drawing.Size(87, 42)
        Me.ProcurarCliente.TabIndex = 9
        Me.ProcurarCliente.Text = "Procurar Cliente"
        Me.ProcurarCliente.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(3, 36)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(89, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Data Nascimento"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(3, 86)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(24, 13)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "NIF"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(3, 136)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(73, 13)
        Me.Label7.TabIndex = 31
        Me.Label7.Text = "Data Reserva"
        '
        'NomeCliente
        '
        Me.NomeCliente.Location = New System.Drawing.Point(98, 3)
        Me.NomeCliente.Name = "NomeCliente"
        Me.NomeCliente.Size = New System.Drawing.Size(200, 20)
        Me.NomeCliente.TabIndex = 0
        '
        'NIF
        '
        Me.NIF.Location = New System.Drawing.Point(98, 89)
        Me.NIF.Name = "NIF"
        Me.NIF.Size = New System.Drawing.Size(200, 20)
        Me.NIF.TabIndex = 2
        '
        'FazerReserva
        '
        Me.FazerReserva.Location = New System.Drawing.Point(371, 89)
        Me.FazerReserva.Name = "FazerReserva"
        Me.FazerReserva.Size = New System.Drawing.Size(87, 42)
        Me.FazerReserva.TabIndex = 28
        Me.FazerReserva.Text = "Fazer Reserva"
        Me.FazerReserva.UseVisualStyleBackColor = True
        '
        'DataNascimento
        '
        Me.DataNascimento.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DataNascimento.Location = New System.Drawing.Point(98, 39)
        Me.DataNascimento.Name = "DataNascimento"
        Me.DataNascimento.Size = New System.Drawing.Size(200, 20)
        Me.DataNascimento.TabIndex = 3
        '
        'DataReserva
        '
        Me.DataReserva.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DataReserva.Location = New System.Drawing.Point(98, 139)
        Me.DataReserva.Name = "DataReserva"
        Me.DataReserva.Size = New System.Drawing.Size(200, 20)
        Me.DataReserva.TabIndex = 30
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(3, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(65, 13)
        Me.Label4.TabIndex = 43
        Me.Label4.Text = "Ingredientes"
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 2
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.91054!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 85.08946!))
        Me.TableLayoutPanel2.Controls.Add(Me.TextBox1, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Label4, 0, 0)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(26, 541)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(758, 34)
        Me.TableLayoutPanel2.TabIndex = 57
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.ColumnCount = 4
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel3.Controls.Add(Me.Label5, 0, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.ReceitaTotal, 1, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.Label8, 2, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.CustoTotal, 3, 0)
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(26, 581)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 1
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(758, 34)
        Me.TableLayoutPanel3.TabIndex = 58
        '
        'Numero
        '
        Me.Numero.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Numero.Location = New System.Drawing.Point(407, 14)
        Me.Numero.Name = "Numero"
        Me.Numero.Size = New System.Drawing.Size(255, 20)
        Me.Numero.TabIndex = 59
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(25, 252)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(70, 16)
        Me.Label3.TabIndex = 60
        Me.Label3.Text = "Entradas"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(212, 252)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(126, 16)
        Me.Label6.TabIndex = 61
        Me.Label6.Text = "Pratos Principais"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(398, 252)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(96, 16)
        Me.Label9.TabIndex = 62
        Me.Label9.Text = "Sobremesas"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(584, 254)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(103, 16)
        Me.Label10.TabIndex = 63
        Me.Label10.Text = "Pratos do Dia"
        '
        'FormReserva
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1025, 627)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Numero)
        Me.Controls.Add(Me.Botao2)
        Me.Controls.Add(Me.TableLayoutPanel3)
        Me.Controls.Add(Me.Botao1)
        Me.Controls.Add(Me.TableLayoutPanel2)
        Me.Controls.Add(Me.Botao3)
        Me.Controls.Add(Me.FlowLayoutPanel3)
        Me.Controls.Add(Me.Botao4)
        Me.Controls.Add(Me.FlowLayoutPanel1)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "FormReserva"
        Me.Text = "FormReserva"
        Me.FlowLayoutPanel3.ResumeLayout(False)
        CType(Me.GridPratos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.TableLayoutPanel3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Botao2 As Button
    Friend WithEvents Botao1 As Button
    Friend WithEvents Botao3 As Button
    Friend WithEvents Botao4 As Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents ReceitaTotal As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents CustoTotal As TextBox
    Friend WithEvents FlowLayoutPanel3 As FlowLayoutPanel
    Friend WithEvents GridPratos As DataGridView
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents CheckedListBox4 As CheckedListBox
    Friend WithEvents CheckedListBox3 As CheckedListBox
    Friend WithEvents CheckedListBox2 As CheckedListBox
    Friend WithEvents CheckedListBox1 As CheckedListBox
    Friend WithEvents FlowLayoutPanel2 As FlowLayoutPanel
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents Nome As Label
    Friend WithEvents ProcurarCliente As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents NomeCliente As TextBox
    Friend WithEvents NIF As TextBox
    Friend WithEvents FazerReserva As Button
    Friend WithEvents DataNascimento As DateTimePicker
    Friend WithEvents DataReserva As DateTimePicker
    Friend WithEvents Label4 As Label
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel3 As TableLayoutPanel
    Friend WithEvents Numero As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
End Class
