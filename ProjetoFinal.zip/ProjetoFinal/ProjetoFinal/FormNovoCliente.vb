﻿Public Class FormNovoCliente
    Private Sub FormNovoCliente_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim cliente As Cliente
        cliente = New Cliente(NomeClienteTB.Text, DateTimePicker1.Value, NIFCLiente.Text)
        Cadeia.Clientes.Add(cliente)
        Me.Close()
        gravar()
    End Sub
    Public Sub gravar()
        Dim writer As New System.Xml.Serialization.XmlSerializer(GetType(CadeiaRestaurantes))

        Dim file As New System.IO.StreamWriter("InformacaoRestaurantessss.xml")

        writer.Serialize(file, Cadeia)

        file.Close()
    End Sub
End Class