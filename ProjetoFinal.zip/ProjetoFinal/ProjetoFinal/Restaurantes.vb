﻿Public Class Restaurantes
    Inherits Collections.CollectionBase




    Public Sub New()

    End Sub
    Public Sub Add(ByVal NewRestaurante As Restaurante)
        Me.List.Add(NewRestaurante)
    End Sub

    Public Sub Remove(ByVal oldRestaurante As Restaurante)
        Me.List.Remove(oldRestaurante)
    End Sub

    Default Public Property item(ByVal index As Integer) As Restaurante
        Get
            Return Me.List.Item(index)
        End Get
        Set(ByVal value As Restaurante)
            Me.List.Item(index) = value
        End Set
    End Property



    Public Shadows Sub clear()
        MyBase.Clear()
    End Sub

    Public Shadows Sub RemoveAt(ByVal index As Integer)
        Remove(item(index))
    End Sub
    Public Sub InsertAt(ByVal index As Integer, ByVal NewRestaurante As Restaurante)
        Me.List.Insert(index, NewRestaurante)
    End Sub

End Class
