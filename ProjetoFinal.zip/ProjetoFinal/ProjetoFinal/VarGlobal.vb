﻿Module VarGlobal
    Public Cadeia As CadeiaRestaurantes
    Public visivel2 As Integer
    Public restaurante As New Restaurante
    Public visivel3 As Integer
    Public Sub initvars()
        Cadeia = New CadeiaRestaurantes
        ler()

        If Cadeia.Restaurantes.Count > 0 Then
            visivel2 = Cadeia.Restaurantes.Count - 1
            visivel3 = Cadeia.Clientes.Count
        Else
            Cadeia.Restaurantes.Add(restaurante)
            visivel2 = 0
            visivel3 = 0

        End If

    End Sub

    Public Sub ler()
        Dim reader As New System.Xml.Serialization.XmlSerializer(GetType(CadeiaRestaurantes))

        If System.IO.File.Exists("InformacaoRestaurantessss.xml") Then
            Dim file As New System.IO.StreamReader("InformacaoRestaurantessss.xml")

            Cadeia = CType(reader.Deserialize(file), CadeiaRestaurantes)

            file.Close()
        End If
    End Sub
End Module
