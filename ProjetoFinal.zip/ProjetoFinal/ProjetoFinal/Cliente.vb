﻿Public Class Cliente
    Private _idade As Integer = 0
    Private _nome As String = "Nome"
    Private _dataNascimento As Date = Today
    Private _reservas As New ArrayList
    Private _nIF As Integer = 0

    Public Property Idade As Integer
        Get
            Return _idade
        End Get
        Set(value As Integer)
            _idade = calcular()
        End Set
    End Property

    Public Property Nome As String
        Get
            Return _nome
        End Get
        Set(value As String)
            _nome = value
        End Set
    End Property

    Public Property DataNascimento As Date
        Get
            Return _dataNascimento
        End Get
        Set(value As Date)
            _dataNascimento = value
        End Set
    End Property

    Public Property Reservas As ArrayList
        Get
            Return _reservas
        End Get
        Set(value As ArrayList)
            _reservas = value
        End Set
    End Property

    Public Property NIF As Integer
        Get
            Return _nIF
        End Get
        Set(value As Integer)
            _nIF = value
        End Set
    End Property

    Public Sub New()

    End Sub
    Public Sub New(ByVal nome As String, ByVal data As Date, ByVal nif As Integer)
        Me.Nome = nome
        Me.DataNascimento = data
        Me.Idade = calcular()
        Me.NIF = nif
    End Sub

    Public Function calcular() As Integer
        Dim Temp As Integer
        Temp = DateDiff(DateInterval.Year, Me.DataNascimento, Today)

        If Me.DataNascimento.Month < Today.Month Then
            Temp = Temp - 1
        ElseIf Me.DataNascimento.Month = Today.Month Then
            If Me.DataNascimento.Day < Today.Day Then
                Temp = Temp - 1
            End If
        End If

        Return Temp

    End Function


End Class
