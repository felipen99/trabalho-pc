﻿Public Class FormReserva

    Public Event fechar()
    Dim custototoal As Single
    Dim pratos As New Pratos
    Dim pratosdias As New PratoDias
    Private Sub FormRestaurantes_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        inicial()
        mostra()


    End Sub

    Private Sub FormRestaurantes_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        RaiseEvent fechar()
    End Sub

    Private Sub ProcurarCliente_Click(sender As Object, e As EventArgs) Handles ProcurarCliente.Click
        Dim encontrado As Boolean = False
        For k = 0 To Cadeia.Clientes.Count - 1
            If Cadeia.Clientes(k).NIF = NIF.Text Then
                encontrado = True
                NomeCliente.Text = Cadeia.Clientes(k).Nome
                DataNascimento.Value = Cadeia.Clientes(k).DataNascimento
            End If
        Next
        If Not encontrado Then
            MsgBox("Não existe nenhum cliente com esse NIF!")
        End If
    End Sub

    Public Sub mostra()


        If Cadeia.Restaurantes.Count > 0 Then
            If visivel2 < 0 Then
                visivel2 = 0
            ElseIf visivel2 > cadeia.restaurantes.Count - 1 Then
                visivel2 = Cadeia.Restaurantes.Count - 1
            End If

        Else
            inicial()
        End If

        If visivel2 = 0 Then
            Botao3.Enabled = True
            Botao4.Enabled = True
            Botao1.Enabled = False
            Botao2.Enabled = False
        ElseIf visivel2 = Cadeia.Restaurantes.Count - 1 Then
            Botao1.Enabled = True
            Botao2.Enabled = True
            Botao3.Enabled = False
            Botao4.Enabled = False

        Else
            Botao1.Enabled = True
            Botao2.Enabled = True
            Botao3.Enabled = True
            Botao4.Enabled = True
        End If

        If Cadeia.Restaurantes.Count = 1 Then
            Botao1.Enabled = False
            Botao2.Enabled = False
            Botao3.Enabled = False
            Botao4.Enabled = False
        End If

        GridPratos.Columns.Clear()

        GridPratos.ColumnCount = 4

        Dim total As Integer
        Dim temp As Integer
        total = CheckedListBox1.CheckedItems.Count
        If CheckedListBox2.CheckedItems.Count > CheckedListBox3.CheckedItems.Count Then
            temp = CheckedListBox2.Items.Count
        Else
            temp = CheckedListBox3.CheckedItems.Count
        End If

        If total < temp Then
            total = temp
        End If
        If CheckedListBox4.CheckedItems.Count > total Then
            total = CheckedListBox4.CheckedItems.Count
        End If

        If total > 0 Then
            GridPratos.RowCount = total
        End If


        Dim i As Integer = 0

        For Each column As DataGridViewColumn In GridPratos.Columns
            If i = 0 Then
                column.HeaderText = "Entrada(s)"
            ElseIf i = 1 Then
                column.HeaderText = "Prato Principal"
            ElseIf i = 2 Then
                column.HeaderText = "Sobremesa(s)"
            ElseIf i = 3 Then
                column.HeaderText = "Pratos do Dia"
            End If
            i = i + 1
        Next
        custototoal = 0
        pratos.clear()
        pratosdias.clear()

        grid(CheckedListBox1, 0)
        grid(CheckedListBox2, 1)
        grid(CheckedListBox3, 2)
        grid2(CheckedListBox4, 3)

        CustoTotal.Text = custototoal
        Dim pos As Integer = -1
        pos = Cadeia.Restaurantes(visivel2).quantidades
        If pos >= 0 Then
            TextBox1.Text = "Não existe quantidade suficientes do ingrediente " & Cadeia.Restaurantes(visivel2).Ingredientes(pos).Nome & ".Quantidade Necessária: " & -Cadeia.Restaurantes(visivel2).Ingredientes(pos).Quantidade
            Label4.BackColor = Color.Red
        Else
            TextBox1.Text = "Existem quantidades suficientes de todos os ingredientes"
            Label4.BackColor = Color.Green
        End If

        ReceitaTotal.Text = Cadeia.Restaurantes(visivel2).Receitatotal
        Numero.Text = "Restaurante " & Cadeia.Restaurantes(visivel2).Nome
    End Sub

    Private Sub Botao1_Click(sender As Object, e As EventArgs) Handles Botao1.Click
        visivel2 = 0
        inicial()
        mostra()
    End Sub

    Private Sub Botao2_Click(sender As Object, e As EventArgs) Handles Botao2.Click
        visivel2 = visivel2 - 1
        inicial()
        mostra()
    End Sub

    Private Sub Botao3_Click(sender As Object, e As EventArgs) Handles Botao3.Click
        visivel2 = visivel2 + 1
        inicial()
        mostra()
    End Sub

    Private Sub Botao4_Click(sender As Object, e As EventArgs) Handles Botao4.Click
        visivel2 = Cadeia.Restaurantes.Count - 1
        inicial()
        mostra()
    End Sub

    Public Sub inicial()
        NomeCliente.Enabled = False
        DataNascimento.Enabled = False

        CheckedListBox1.Items.Clear()
        CheckedListBox2.Items.Clear()
        CheckedListBox3.Items.Clear()


        For k = 0 To Cadeia.Restaurantes(visivel2).Pratos.Count - 1
            If UCase(Cadeia.Restaurantes(visivel2).Pratos(k).Tipo) = "ENTRADA" Then
                CheckedListBox1.Items.Add(Cadeia.Restaurantes(visivel2).Pratos(k).Nome & " (" & Cadeia.Restaurantes(visivel2).Pratos(k).Preco & ")")
            ElseIf UCase(cadeia.restaurantes(visivel2).Pratos(k).Tipo) = "PRATO PRINCIPAL" Then
                CheckedListBox2.Items.Add(Cadeia.Restaurantes(visivel2).Pratos(k).Nome & " (" & Cadeia.Restaurantes(visivel2).Pratos(k).Preco & ")")
            Else
                CheckedListBox3.Items.Add(Cadeia.Restaurantes(visivel2).Pratos(k).Nome & " (" & Cadeia.Restaurantes(visivel2).Pratos(k).Preco & ")")
            End If
        Next




        mudadata()
        TextBox1.Enabled = False
        CustoTotal.Enabled = False
    End Sub





    Private Sub CheckedListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CheckedListBox1.SelectedIndexChanged
        mostra()
    End Sub

    Private Sub CheckedListBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CheckedListBox2.SelectedIndexChanged
        mostra()
    End Sub

    Private Sub CheckedListBox3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CheckedListBox3.SelectedIndexChanged
        mostra()
    End Sub
    Private Sub CheckedListBox4_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CheckedListBox4.SelectedIndexChanged
        mostra()
    End Sub



    Public Sub grid(ByVal lista As CheckedListBox, ByVal numero As Integer)
        Dim temp As Integer
        Dim resultado As Boolean = False
        Dim custo As Double
        Dim nome As String
        If lista.CheckedItems.Count > 0 Then
            For k = 0 To lista.CheckedItems.Count - 1
                GridPratos.Item(numero, k).Value = lista.CheckedItems(k)

                temp = Len(lista.CheckedItems(k))
                While temp >= 1
                    If Mid(lista.CheckedItems(k), temp, 1) = " " Then
                        resultado = True
                        custo = Val(Mid(lista.CheckedItems(k), temp + 2, Len(lista.CheckedItems(k)) - temp - 2))
                        nome = Trim(Mid(lista.CheckedItems(k), 1, temp))

                        For m = 0 To Cadeia.Restaurantes(visivel2).Pratos.Count - 1

                            If Cadeia.Restaurantes(visivel2).Pratos(m).Nome = nome Then
                                pratos.Add(Cadeia.Restaurantes(visivel2).Pratos(m))
                            End If
                        Next
                        custototoal = custototoal + custo
                    End If
                    temp = temp - 1
                End While
            Next
        Else
            GridPratos.Item(numero, 0).Value = ""
        End If


    End Sub

    Private Sub FazerReserva_Click(sender As Object, e As EventArgs) Handles FazerReserva.Click
        Dim cliente As New Cliente
        For k = 0 To Cadeia.Clientes.Count - 1
            If NomeCliente.Text = Cadeia.Clientes(k).Nome Then
                cliente = Cadeia.Clientes(k)
            End If
        Next


        If Cadeia.Restaurantes(visivel2).Pratodias.Count > 0 Then
            If Not Cadeia.Restaurantes(visivel2).reservar(cliente, pratos, DataReserva.Value, pratosdias) Then
                MsgBox("Não é possivel realizar a reserva")
            End If
        End If

        If Not Cadeia.Restaurantes(visivel2).reservar(cliente, pratos, DataReserva.Value) Then
            MsgBox("Nao é possivel realizar a reserva")
        End If

        mostra()
        RaiseEvent fechar()

    End Sub

    Private Sub DataReserva_ValueChanged(sender As Object, e As EventArgs) Handles DataReserva.ValueChanged
        mudadata()
        mostra()
    End Sub

    Public Sub grid2(ByVal lista As CheckedListBox, ByVal numero As Integer)
        Dim temp As Integer
        Dim resultado As Boolean = False
        Dim custo As Single
        Dim nome As String
        If lista.CheckedItems.Count > 0 Then
            For k = 0 To lista.CheckedItems.Count - 1
                GridPratos.Item(numero, k).Value = lista.CheckedItems(k)

                temp = Len(lista.CheckedItems(k))
                While temp >= 1
                    If Mid(lista.CheckedItems(k), temp, 1) = " " Then
                        resultado = True
                        custo = Val(Mid(lista.CheckedItems(k), temp + 2, Len(lista.CheckedItems(k)) - temp - 2))

                        nome = Trim(Mid(lista.CheckedItems(k), 1, temp))

                        For m = 0 To Cadeia.Restaurantes(visivel2).Pratodias.Count - 1

                            If Cadeia.Restaurantes(visivel2).Pratodias(m).Nome = nome Then
                                pratosdias.Add(Cadeia.Restaurantes(visivel2).Pratodias(m))
                            End If
                        Next
                        custototoal = custototoal + custo
                    End If
                    temp = temp - 1
                End While
            Next
        Else
            GridPratos.Item(numero, 0).Value = ""
        End If

    End Sub
    Public Sub mudadata()
        CheckedListBox4.Items.Clear()

        For k = 0 To Cadeia.Restaurantes(visivel2).Pratodias.Count - 1

            If Cadeia.Restaurantes(visivel2).Pratodias(k).Data.DayOfYear = DataReserva.Value.DayOfYear Then
                CheckedListBox4.Items.Add(Cadeia.Restaurantes(visivel2).Pratodias(k).Nome & " (" & Cadeia.Restaurantes(visivel2).Pratodias(k).Preco & ")")

            End If

        Next
    End Sub

End Class