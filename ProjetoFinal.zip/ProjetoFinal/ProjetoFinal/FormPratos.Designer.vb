﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormPratos
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Lista = New System.Windows.Forms.CheckedListBox()
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.RegPratoDia = New System.Windows.Forms.Button()
        Me.CriarPratoDia = New System.Windows.Forms.Button()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.Nome = New System.Windows.Forms.Label()
        Me.PrecoPrato = New System.Windows.Forms.Label()
        Me.NomePrato = New System.Windows.Forms.TextBox()
        Me.Preco = New System.Windows.Forms.TextBox()
        Me.Sobremesa = New System.Windows.Forms.Button()
        Me.TipoPrato = New System.Windows.Forms.TextBox()
        Me.NovoPrecoTB = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.CriarPrato = New System.Windows.Forms.Button()
        Me.RegistarPrato = New System.Windows.Forms.Button()
        Me.AlterarPreco = New System.Windows.Forms.Button()
        Me.Entrada = New System.Windows.Forms.Button()
        Me.PratoPrincipal = New System.Windows.Forms.Button()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Numero = New System.Windows.Forms.TextBox()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.ListaPratosDia = New System.Windows.Forms.ListBox()
        Me.ListaPratos = New System.Windows.Forms.ListBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.PratoDias = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Botao1 = New System.Windows.Forms.Button()
        Me.Pratos = New System.Windows.Forms.Label()
        Me.Botao2 = New System.Windows.Forms.Button()
        Me.Botao3 = New System.Windows.Forms.Button()
        Me.Botao4 = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Controls.Add(Me.Label1)
        Me.FlowLayoutPanel1.Controls.Add(Me.Lista)
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(58, 426)
        Me.FlowLayoutPanel1.Margin = New System.Windows.Forms.Padding(2)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(421, 201)
        Me.FlowLayoutPanel1.TabIndex = 94
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(3, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(234, 13)
        Me.Label1.TabIndex = 47
        Me.Label1.Text = "Nome e Quantidade Respetiva dos Ingredientes"
        '
        'Lista
        '
        Me.Lista.FormattingEnabled = True
        Me.Lista.Location = New System.Drawing.Point(3, 16)
        Me.Lista.Name = "Lista"
        Me.Lista.Size = New System.Drawing.Size(392, 169)
        Me.Lista.TabIndex = 1
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.ColumnCount = 4
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 187.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 87.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 86.0!))
        Me.TableLayoutPanel4.Controls.Add(Me.Label3, 0, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.RegPratoDia, 3, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.CriarPratoDia, 2, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.DateTimePicker1, 1, 0)
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(58, 348)
        Me.TableLayoutPanel4.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 1
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(440, 66)
        Me.TableLayoutPanel4.TabIndex = 93
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(3, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(30, 13)
        Me.Label3.TabIndex = 59
        Me.Label3.Text = "Data"
        '
        'RegPratoDia
        '
        Me.RegPratoDia.Location = New System.Drawing.Point(357, 3)
        Me.RegPratoDia.Name = "RegPratoDia"
        Me.RegPratoDia.Size = New System.Drawing.Size(76, 45)
        Me.RegPratoDia.TabIndex = 62
        Me.RegPratoDia.Text = "Registar Prato do Dia"
        Me.RegPratoDia.UseVisualStyleBackColor = True
        '
        'CriarPratoDia
        '
        Me.CriarPratoDia.Location = New System.Drawing.Point(270, 3)
        Me.CriarPratoDia.Name = "CriarPratoDia"
        Me.CriarPratoDia.Size = New System.Drawing.Size(77, 45)
        Me.CriarPratoDia.TabIndex = 66
        Me.CriarPratoDia.Text = "Criar Prato do Dia"
        Me.CriarPratoDia.UseVisualStyleBackColor = True
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTimePicker1.Location = New System.Drawing.Point(83, 3)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(107, 20)
        Me.DateTimePicker1.TabIndex = 49
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.ColumnCount = 4
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel3.Controls.Add(Me.Nome, 0, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.PrecoPrato, 0, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.NomePrato, 1, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.Preco, 1, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.Sobremesa, 2, 2)
        Me.TableLayoutPanel3.Controls.Add(Me.TipoPrato, 1, 3)
        Me.TableLayoutPanel3.Controls.Add(Me.NovoPrecoTB, 1, 4)
        Me.TableLayoutPanel3.Controls.Add(Me.Label2, 0, 4)
        Me.TableLayoutPanel3.Controls.Add(Me.CriarPrato, 3, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.RegistarPrato, 3, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.AlterarPreco, 2, 4)
        Me.TableLayoutPanel3.Controls.Add(Me.Entrada, 0, 2)
        Me.TableLayoutPanel3.Controls.Add(Me.PratoPrincipal, 1, 2)
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(58, 63)
        Me.TableLayoutPanel3.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 2
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 42.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 49.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 51.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 15.0!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(394, 227)
        Me.TableLayoutPanel3.TabIndex = 92
        '
        'Nome
        '
        Me.Nome.AutoSize = True
        Me.Nome.Location = New System.Drawing.Point(3, 0)
        Me.Nome.Name = "Nome"
        Me.Nome.Size = New System.Drawing.Size(35, 13)
        Me.Nome.TabIndex = 38
        Me.Nome.Text = "Nome"
        '
        'PrecoPrato
        '
        Me.PrecoPrato.AutoSize = True
        Me.PrecoPrato.Location = New System.Drawing.Point(3, 45)
        Me.PrecoPrato.Name = "PrecoPrato"
        Me.PrecoPrato.Size = New System.Drawing.Size(35, 13)
        Me.PrecoPrato.TabIndex = 39
        Me.PrecoPrato.Text = "Preço"
        '
        'NomePrato
        '
        Me.NomePrato.Location = New System.Drawing.Point(85, 3)
        Me.NomePrato.Name = "NomePrato"
        Me.NomePrato.Size = New System.Drawing.Size(100, 20)
        Me.NomePrato.TabIndex = 36
        '
        'Preco
        '
        Me.Preco.Location = New System.Drawing.Point(85, 48)
        Me.Preco.Name = "Preco"
        Me.Preco.Size = New System.Drawing.Size(100, 20)
        Me.Preco.TabIndex = 37
        '
        'Sobremesa
        '
        Me.Sobremesa.Location = New System.Drawing.Point(191, 90)
        Me.Sobremesa.Name = "Sobremesa"
        Me.Sobremesa.Size = New System.Drawing.Size(87, 27)
        Me.Sobremesa.TabIndex = 42
        Me.Sobremesa.Text = "Sobremesa"
        Me.Sobremesa.UseVisualStyleBackColor = True
        '
        'TipoPrato
        '
        Me.TipoPrato.Location = New System.Drawing.Point(85, 139)
        Me.TipoPrato.Name = "TipoPrato"
        Me.TipoPrato.Size = New System.Drawing.Size(100, 20)
        Me.TipoPrato.TabIndex = 44
        Me.TipoPrato.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NovoPrecoTB
        '
        Me.NovoPrecoTB.Location = New System.Drawing.Point(85, 190)
        Me.NovoPrecoTB.Name = "NovoPrecoTB"
        Me.NovoPrecoTB.Size = New System.Drawing.Size(100, 20)
        Me.NovoPrecoTB.TabIndex = 63
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(3, 187)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 13)
        Me.Label2.TabIndex = 65
        Me.Label2.Text = "Novo Preço"
        '
        'CriarPrato
        '
        Me.CriarPrato.Location = New System.Drawing.Point(284, 3)
        Me.CriarPrato.Name = "CriarPrato"
        Me.CriarPrato.Size = New System.Drawing.Size(93, 39)
        Me.CriarPrato.TabIndex = 45
        Me.CriarPrato.Text = "Criar Prato"
        Me.CriarPrato.UseVisualStyleBackColor = True
        '
        'RegistarPrato
        '
        Me.RegistarPrato.Location = New System.Drawing.Point(284, 48)
        Me.RegistarPrato.Name = "RegistarPrato"
        Me.RegistarPrato.Size = New System.Drawing.Size(93, 36)
        Me.RegistarPrato.TabIndex = 46
        Me.RegistarPrato.Text = "Registar Prato"
        Me.RegistarPrato.UseVisualStyleBackColor = True
        '
        'AlterarPreco
        '
        Me.AlterarPreco.Location = New System.Drawing.Point(191, 190)
        Me.AlterarPreco.Name = "AlterarPreco"
        Me.AlterarPreco.Size = New System.Drawing.Size(87, 34)
        Me.AlterarPreco.TabIndex = 64
        Me.AlterarPreco.Text = "Alterar Preço"
        Me.AlterarPreco.UseVisualStyleBackColor = True
        '
        'Entrada
        '
        Me.Entrada.Location = New System.Drawing.Point(3, 90)
        Me.Entrada.Name = "Entrada"
        Me.Entrada.Size = New System.Drawing.Size(76, 28)
        Me.Entrada.TabIndex = 41
        Me.Entrada.Text = "Entrada"
        Me.Entrada.UseVisualStyleBackColor = True
        '
        'PratoPrincipal
        '
        Me.PratoPrincipal.Location = New System.Drawing.Point(85, 90)
        Me.PratoPrincipal.Name = "PratoPrincipal"
        Me.PratoPrincipal.Size = New System.Drawing.Size(99, 27)
        Me.PratoPrincipal.TabIndex = 43
        Me.PratoPrincipal.Text = "PratoPrincipal"
        Me.PratoPrincipal.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 6
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 51.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 202.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 49.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.Button6, 3, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Numero, 4, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Button5, 5, 0)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(562, 45)
        Me.TableLayoutPanel2.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(302, 31)
        Me.TableLayoutPanel2.TabIndex = 91
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(3, 3)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(45, 23)
        Me.Button6.TabIndex = 74
        Me.Button6.Text = "<"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Numero
        '
        Me.Numero.Location = New System.Drawing.Point(54, 3)
        Me.Numero.Name = "Numero"
        Me.Numero.Size = New System.Drawing.Size(196, 20)
        Me.Numero.TabIndex = 73
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(256, 3)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(43, 23)
        Me.Button5.TabIndex = 72
        Me.Button5.Text = ">"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 3
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 131.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 147.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.ListaPratosDia, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.ListaPratos, 0, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(562, 114)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 496.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(302, 496)
        Me.TableLayoutPanel1.TabIndex = 90
        '
        'ListaPratosDia
        '
        Me.ListaPratosDia.FormattingEnabled = True
        Me.ListaPratosDia.Location = New System.Drawing.Point(174, 3)
        Me.ListaPratosDia.Name = "ListaPratosDia"
        Me.ListaPratosDia.Size = New System.Drawing.Size(123, 485)
        Me.ListaPratosDia.TabIndex = 48
        '
        'ListaPratos
        '
        Me.ListaPratos.FormattingEnabled = True
        Me.ListaPratos.Location = New System.Drawing.Point(3, 3)
        Me.ListaPratos.Name = "ListaPratos"
        Me.ListaPratos.Size = New System.Drawing.Size(123, 485)
        Me.ListaPratos.TabIndex = 0
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(262, 314)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(45, 23)
        Me.Button4.TabIndex = 89
        Me.Button4.Text = ">>"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(205, 314)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(45, 23)
        Me.Button3.TabIndex = 88
        Me.Button3.Text = ">"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'PratoDias
        '
        Me.PratoDias.AutoSize = True
        Me.PratoDias.Location = New System.Drawing.Point(162, 319)
        Me.PratoDias.Name = "PratoDias"
        Me.PratoDias.Size = New System.Drawing.Size(37, 13)
        Me.PratoDias.TabIndex = 87
        Me.PratoDias.Text = "0 de 0"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(111, 314)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(45, 23)
        Me.Button2.TabIndex = 86
        Me.Button2.Text = "<"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(58, 314)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(45, 23)
        Me.Button1.TabIndex = 85
        Me.Button1.Text = "<<"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Botao1
        '
        Me.Botao1.Location = New System.Drawing.Point(58, 18)
        Me.Botao1.Name = "Botao1"
        Me.Botao1.Size = New System.Drawing.Size(45, 23)
        Me.Botao1.TabIndex = 84
        Me.Botao1.Text = "<<"
        Me.Botao1.UseVisualStyleBackColor = True
        '
        'Pratos
        '
        Me.Pratos.AutoSize = True
        Me.Pratos.Location = New System.Drawing.Point(162, 23)
        Me.Pratos.Name = "Pratos"
        Me.Pratos.Size = New System.Drawing.Size(37, 13)
        Me.Pratos.TabIndex = 83
        Me.Pratos.Text = "0 de 0"
        '
        'Botao2
        '
        Me.Botao2.Location = New System.Drawing.Point(111, 18)
        Me.Botao2.Name = "Botao2"
        Me.Botao2.Size = New System.Drawing.Size(45, 23)
        Me.Botao2.TabIndex = 82
        Me.Botao2.Text = "<"
        Me.Botao2.UseVisualStyleBackColor = True
        '
        'Botao3
        '
        Me.Botao3.Location = New System.Drawing.Point(205, 18)
        Me.Botao3.Name = "Botao3"
        Me.Botao3.Size = New System.Drawing.Size(45, 23)
        Me.Botao3.TabIndex = 81
        Me.Botao3.Text = ">"
        Me.Botao3.UseVisualStyleBackColor = True
        '
        'Botao4
        '
        Me.Botao4.Location = New System.Drawing.Point(262, 18)
        Me.Botao4.Name = "Botao4"
        Me.Botao4.Size = New System.Drawing.Size(45, 23)
        Me.Botao4.TabIndex = 80
        Me.Botao4.Text = ">>"
        Me.Botao4.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(562, 92)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(53, 16)
        Me.Label4.TabIndex = 95
        Me.Label4.Text = "Pratos"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(733, 92)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(103, 16)
        Me.Label5.TabIndex = 96
        Me.Label5.Text = "Pratos do Dia"
        '
        'FormPratos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(923, 685)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.FlowLayoutPanel1)
        Me.Controls.Add(Me.TableLayoutPanel4)
        Me.Controls.Add(Me.TableLayoutPanel3)
        Me.Controls.Add(Me.TableLayoutPanel2)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.PratoDias)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Botao1)
        Me.Controls.Add(Me.Pratos)
        Me.Controls.Add(Me.Botao2)
        Me.Controls.Add(Me.Botao3)
        Me.Controls.Add(Me.Botao4)
        Me.Name = "FormPratos"
        Me.Text = "FormPratos"
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.FlowLayoutPanel1.PerformLayout()
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.TableLayoutPanel4.PerformLayout()
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.TableLayoutPanel3.PerformLayout()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents Label1 As Label
    Friend WithEvents Lista As CheckedListBox
    Friend WithEvents TableLayoutPanel4 As TableLayoutPanel
    Friend WithEvents Label3 As Label
    Friend WithEvents RegPratoDia As Button
    Friend WithEvents CriarPratoDia As Button
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents TableLayoutPanel3 As TableLayoutPanel
    Friend WithEvents Nome As Label
    Friend WithEvents PrecoPrato As Label
    Friend WithEvents NomePrato As TextBox
    Friend WithEvents Preco As TextBox
    Friend WithEvents Sobremesa As Button
    Friend WithEvents TipoPrato As TextBox
    Friend WithEvents NovoPrecoTB As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents CriarPrato As Button
    Friend WithEvents RegistarPrato As Button
    Friend WithEvents AlterarPreco As Button
    Friend WithEvents Entrada As Button
    Friend WithEvents PratoPrincipal As Button
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Numero As TextBox
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents ListaPratosDia As ListBox
    Friend WithEvents ListaPratos As ListBox
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents PratoDias As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Botao1 As Button
    Friend WithEvents Pratos As Label
    Friend WithEvents Botao2 As Button
    Friend WithEvents Botao3 As Button
    Friend WithEvents Botao4 As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
End Class
