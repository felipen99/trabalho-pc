﻿Imports ProjetoFinal

Public Class CadeiaRestaurantes
    Private _restaurantes As New Restaurantes
    Private _clientes As New Clientes

    Public Sub New()

    End Sub

    Public Property Restaurantes As Restaurantes
        Get
            Return _restaurantes
        End Get
        Set(value As Restaurantes)
            _restaurantes = value
        End Set
    End Property

    Public Property Clientes As Clientes
        Get
            Return _clientes
        End Get
        Set(value As Clientes)
            _clientes = value
        End Set
    End Property
End Class
