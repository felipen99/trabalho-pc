﻿Public Class Inicial
    Public WithEvents restaurantes As New FormRestaurantes
    Private correto As Boolean
    Public Event loginok()
    Public Event loginerrado(ByVal nome As String)
    Private Sub Inicial_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        VarGlobal.initvars()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim resultado As Boolean = False
        For k = 0 To Cadeia.Clientes.Count - 1
            If Cadeia.Clientes(k).NIF = NifCliente.Text Then
                resultado = True
                MsgBox("Bem-vindo")
                Me.Close()
                restaurantes.NomeCliente.Text = Cadeia.Clientes(k).Nome
                restaurantes.NIF.Text = Cadeia.Clientes(k).NIF
                restaurantes.DataNascimento.Text = Cadeia.Clientes(k).DataNascimento
                restaurantes.ProcurarCliente.Visible = False

                restaurantes.TextBox1.Visible = False
                restaurantes.Label4.Visible = False
                restaurantes.ShowDialog()


                Exit For
            End If
        Next


        If Not resultado Then
            MsgBox("Não existe nenhum Cliente com esse NIF")
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        entrar()
    End Sub

    Public Function entrar()
        Dim nome As String
        If UCase(Utilizador.Text) = "RESTAURANTE" And UCase(Passe.Text) = "GESTOR" Then
            correto = True
            RaiseEvent loginok()
            Me.Close()
        Else
            MsgBox("Errado")
            correto = False
        End If
        Return nome
    End Function

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        RaiseEvent loginerrado("Login Cancelado")
        Me.Close()
    End Sub

    Private Sub Inicial_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing

    End Sub

    Public NovoCliente As New Form1
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        NovoCliente.ShowDialog()
    End Sub

    Private Sub Inicial_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed

    End Sub

    Private Sub apanhafechar() Handles restaurantes.fechar
        RaiseEvent loginerrado("Obrigado pela Reserva!")
    End Sub
End Class