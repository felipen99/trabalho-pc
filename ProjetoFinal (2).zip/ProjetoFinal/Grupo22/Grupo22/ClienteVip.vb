﻿Imports Grupo22

Public Class ClienteVip : Inherits Cliente
    Private _prato As Prato

    Public Property Prato As Prato
        Get
            Return _prato
        End Get
        Set(value As Prato)
            _prato = value
        End Set
    End Property

    Public Sub New()

    End Sub
    Public Sub New(ByVal nome As String, ByVal DataNascimento As Date, ByVal prato As Prato, ByVal nif As Integer)
        MyBase.New(nome, DataNascimento, nif)
        Me.Prato = prato
    End Sub

    Public Function AlterarPrato(ByVal prato As Prato)
        Dim resultado As Boolean = False
        If prato.Nome <> "" Then
            resultado = True
            Me.Prato = prato
        End If
        Return resultado
    End Function
End Class
