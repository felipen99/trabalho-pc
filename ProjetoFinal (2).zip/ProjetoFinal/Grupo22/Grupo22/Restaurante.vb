﻿Imports Grupo22

Public Class Restaurante
    Private _ingredientes As Ingredientes = Nothing
    Private _clientes As Clientes = Nothing
    Private _clientevips As ClienteVips = Nothing
    Private _nome As String = ""
    Private _pratos As Pratos = Nothing
    Private _pratodias As PratoDias = Nothing
    Private _capacidadetotal As ArrayList
    Private _receitatotal As Integer = 0
    Private _receitaVip As Integer = 0
    Private _capacidadeinicial As Integer = 0

    Public Property Ingredientes As Ingredientes
        Get
            Return _ingredientes
        End Get
        Set(value As Ingredientes)
            _ingredientes = value
        End Set
    End Property

    Public Property Clientes As Clientes
        Get
            Return _clientes
        End Get
        Set(value As Clientes)
            _clientes = value
        End Set
    End Property

    Public Property Clientevips As ClienteVips
        Get
            Return _clientevips
        End Get
        Set(value As ClienteVips)
            _clientevips = value
        End Set
    End Property

    Public Property Nome As String
        Get
            Return _nome
        End Get
        Set(value As String)
            _nome = value
        End Set
    End Property

    Public Property Pratos As Pratos
        Get
            Return _pratos
        End Get
        Set(value As Pratos)
            _pratos = value
        End Set
    End Property

    Public Property Pratodias As PratoDias
        Get
            Return _pratodias
        End Get
        Set(value As PratoDias)
            _pratodias = value
        End Set
    End Property



    Public Property Receitatotal As Integer
        Get
            Return _receitatotal
        End Get
        Set(value As Integer)
            _receitatotal = value
        End Set
    End Property

    Public Property Capacidadetotal As ArrayList
        Get
            Return _capacidadetotal
        End Get
        Set(value As ArrayList)
            _capacidadetotal = value
        End Set
    End Property

    Public Property ReceitaVip As Integer
        Get
            Return _receitaVip
        End Get
        Set(value As Integer)
            _receitaVip = value
        End Set
    End Property

    Public Property Capacidadeinicial As Integer
        Get
            Return _capacidadeinicial
        End Get
        Set(value As Integer)
            _capacidadeinicial = value
            criar()
        End Set
    End Property

    Public Sub New()
        Me.Ingredientes = New Ingredientes
        Me.Clientes = New Clientes
        Me.Pratos = New Pratos
        Me.Pratodias = New PratoDias
        Me.Capacidadetotal = New ArrayList


    End Sub


    Public Sub New(ByVal ingredientes As Ingredientes, ByVal clientes As Clientes, ByVal nome As String, ByVal pratos As Pratos, ByVal pratodias As PratoDias, ByVal capacidade As Integer)
        Me.Capacidadeinicial = capacidade
        Me.Ingredientes = New Ingredientes
        Me.Clientes = New Clientes
        Me.Pratos = New Pratos
        Me.Pratodias = New PratoDias
        Me.Capacidadetotal = New ArrayList
        Me.Ingredientes = ingredientes
        Me.Clientes = clientes
        Me.Nome = nome
        Me.Pratos = pratos
        Me.Pratodias = pratodias
        If capacidade > 0 Then
            criar()
        End If


    End Sub

    Public Sub New(ByVal ingredientes As Ingredientes, ByVal clientes As Clientes, ByVal clientevips As ClienteVips, ByVal nome As String, ByVal pratos As Pratos, ByVal pratodias As PratoDias, ByVal capacidade As Integer)
        Me.Capacidadeinicial = capacidade
        Me.Capacidadetotal = New ArrayList
        Me.Ingredientes = ingredientes
        Me.Clientes = clientes
        Me.Clientevips = clientevips
        Me.Nome = nome
        Me.Pratos = pratos
        Me.Pratodias = pratodias
        If capacidade > 0 Then
            criar()
        End If


    End Sub

    Public Function criar()
        For k = 0 To 100
            Me.Capacidadetotal.Add(Me.Capacidadeinicial)
        Next
    End Function

    Public Overloads Function reservar(ByVal cliente As Cliente, ByVal data As Date)
        Dim resultado As Boolean = False

        If data >= Today And cliente.Nome <> "" Then

            For k = 0 To Me.Clientes.Count - 1
                If Me.Clientes(k).Nome = cliente.Nome Then
                    resultado = True
                    Me.Clientes(k).Reservas.Add(data)
                    Receitatotal = Receitatotal + aleatorio("ENTRADA") + aleatorio("PRATO PRINCIPAL") + aleatorio("SOBREMESA")
                    If Me.Clientes(k).DataNascimento.DayOfYear <> Today.DayOfYear Then
                        ReceitaVip = ReceitaVip + aleatorio("ENTRADA") + aleatorio("PRATO PRINCIPAL") + aleatorio("SOBREMESA")
                    End If
                    Me.Capacidadetotal(DateDiff(DateInterval.Day, Today, data)) = Me.Capacidadetotal(DateDiff(DateInterval.Day, Today, data)) - 1
                End If
            Next


        End If
        Return resultado

    End Function

    Public Overloads Function reservar(ByVal cliente As Cliente, ByVal pratoss As Pratos, ByVal data As Date)
        Dim resultado As Boolean = False
        If Capacidadetotal(DateDiff(DateInterval.Day, Today, data)) > 0 Then
            If data >= Today And cliente.Nome <> "" Then
                resultado = True

                For l = 0 To Pratos.Count - 1
                    Receitatotal = Receitatotal + pratoss(l).lucro
                    retirar(pratoss(l))
                Next


                Capacidadetotal(DateDiff(DateInterval.Day, Today, data)) = Capacidadetotal(DateDiff(DateInterval.Day, Today, data)) - 1




            End If


        End If

        Return resultado

    End Function

    Public Overloads Function reservar(ByVal cliente As Cliente, ByVal pratoss As Pratos, ByVal data As Date, ByVal pratosdias As PratoDias)
        Dim resultado As Boolean = False
        If Capacidadetotal(DateDiff(DateInterval.Day, Today, data)) > 0 Then
            If data >= Today And cliente.Nome <> "" Then
                resultado = True

                For l = 0 To Pratos.Count - 1
                    Receitatotal = Receitatotal + pratoss(l).lucro
                    retirar(pratoss(l))
                Next


                Capacidadetotal(DateDiff(DateInterval.Day, Today, data)) = Capacidadetotal(DateDiff(DateInterval.Day, Today, data)) - 1

                For l = 0 To pratosdias.Count - 1
                    Receitatotal = Receitatotal + pratosdias(l).lucro
                    retirar(pratosdias(l))
                Next


            End If


        End If

        Return resultado

    End Function



    Public Function aleatorio(ByVal refeicao As String)
        Dim pratos2 As Pratos = Nothing
        Dim numeros As Integer = 0
        Dim temp As Integer
        Dim prato2 As Prato = Nothing

        For k = 0 To Me.Pratos.Count - 1
            If Me.Pratos(k).Nome = refeicao Then
                numeros = numeros + 1
                pratos2.Add(Pratos(k))

            End If
        Next

        If numeros >= 1 Then
            temp = Int(Rnd(numeros))
            prato2 = pratos2(temp)
        End If

        retirar(prato2)

        Return prato2.lucro

    End Function

    Public Function quantidades()
        Dim resultado As Integer = -1
        For k = 0 To Me.Ingredientes.Count - 1
            If Me.Ingredientes(k).Quantidade < 0 Then
                resultado = k
            End If
        Next
        Return resultado
    End Function

    Public Function retirar(ByVal prato As Prato)
        For k = 0 To prato.Ingredientes.Count - 1
            For l = 0 To Me.Ingredientes.Count - 1
                If prato.Ingredientes(k).Nome = Me.Ingredientes(l).Nome Then
                    Me.Ingredientes(l).Quantidade = Me.Ingredientes(l).Quantidade - prato.Quantidades(k)
                End If
            Next
        Next
        Return quantidades()
    End Function
End Class
