﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormRestaurantes
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.NomeCliente = New System.Windows.Forms.TextBox()
        Me.NIF = New System.Windows.Forms.TextBox()
        Me.DataNascimento = New System.Windows.Forms.DateTimePicker()
        Me.Nome = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ProcurarCliente = New System.Windows.Forms.Button()
        Me.Botao4 = New System.Windows.Forms.Button()
        Me.Botao3 = New System.Windows.Forms.Button()
        Me.Botao1 = New System.Windows.Forms.Button()
        Me.Botao2 = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.FazerReserva = New System.Windows.Forms.Button()
        Me.Numero = New System.Windows.Forms.Label()
        Me.DataReserva = New System.Windows.Forms.DateTimePicker()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.CustoTotal = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.CheckedListBox1 = New System.Windows.Forms.CheckedListBox()
        Me.CheckedListBox2 = New System.Windows.Forms.CheckedListBox()
        Me.CheckedListBox3 = New System.Windows.Forms.CheckedListBox()
        Me.GridPratos = New System.Windows.Forms.DataGridView()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ReceitaTotal = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.CheckedListBox4 = New System.Windows.Forms.CheckedListBox()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.FlowLayoutPanel2 = New System.Windows.Forms.FlowLayoutPanel()
        Me.FlowLayoutPanel3 = New System.Windows.Forms.FlowLayoutPanel()
        Me.FlowLayoutPanel4 = New System.Windows.Forms.FlowLayoutPanel()
        Me.FlowLayoutPanel5 = New System.Windows.Forms.FlowLayoutPanel()
        CType(Me.GridPratos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.FlowLayoutPanel3.SuspendLayout()
        Me.FlowLayoutPanel4.SuspendLayout()
        Me.FlowLayoutPanel5.SuspendLayout()
        Me.SuspendLayout()
        '
        'NomeCliente
        '
        Me.NomeCliente.Location = New System.Drawing.Point(131, 4)
        Me.NomeCliente.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.NomeCliente.Name = "NomeCliente"
        Me.NomeCliente.Size = New System.Drawing.Size(265, 22)
        Me.NomeCliente.TabIndex = 0
        '
        'NIF
        '
        Me.NIF.Location = New System.Drawing.Point(131, 109)
        Me.NIF.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.NIF.Name = "NIF"
        Me.NIF.Size = New System.Drawing.Size(265, 22)
        Me.NIF.TabIndex = 2
        '
        'DataNascimento
        '
        Me.DataNascimento.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DataNascimento.Location = New System.Drawing.Point(131, 48)
        Me.DataNascimento.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.DataNascimento.Name = "DataNascimento"
        Me.DataNascimento.Size = New System.Drawing.Size(265, 22)
        Me.DataNascimento.TabIndex = 3
        '
        'Nome
        '
        Me.Nome.AutoSize = True
        Me.Nome.Location = New System.Drawing.Point(4, 0)
        Me.Nome.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Nome.Name = "Nome"
        Me.Nome.Size = New System.Drawing.Size(45, 17)
        Me.Nome.TabIndex = 4
        Me.Nome.Text = "Nome"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(4, 44)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(116, 17)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Data Nascimento"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 105)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 17)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "NIF"
        '
        'ProcurarCliente
        '
        Me.ProcurarCliente.Location = New System.Drawing.Point(495, 48)
        Me.ProcurarCliente.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.ProcurarCliente.Name = "ProcurarCliente"
        Me.ProcurarCliente.Size = New System.Drawing.Size(116, 52)
        Me.ProcurarCliente.TabIndex = 9
        Me.ProcurarCliente.Text = "Procurar Cliente"
        Me.ProcurarCliente.UseVisualStyleBackColor = True
        '
        'Botao4
        '
        Me.Botao4.Location = New System.Drawing.Point(264, 4)
        Me.Botao4.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Botao4.Name = "Botao4"
        Me.Botao4.Size = New System.Drawing.Size(60, 28)
        Me.Botao4.TabIndex = 15
        Me.Botao4.Text = ">>"
        Me.Botao4.UseVisualStyleBackColor = True
        '
        'Botao3
        '
        Me.Botao3.Location = New System.Drawing.Point(196, 4)
        Me.Botao3.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Botao3.Name = "Botao3"
        Me.Botao3.Size = New System.Drawing.Size(60, 28)
        Me.Botao3.TabIndex = 16
        Me.Botao3.Text = ">"
        Me.Botao3.UseVisualStyleBackColor = True
        '
        'Botao1
        '
        Me.Botao1.Location = New System.Drawing.Point(72, 4)
        Me.Botao1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Botao1.Name = "Botao1"
        Me.Botao1.Size = New System.Drawing.Size(60, 28)
        Me.Botao1.TabIndex = 17
        Me.Botao1.Text = "<<"
        Me.Botao1.UseVisualStyleBackColor = True
        '
        'Botao2
        '
        Me.Botao2.Location = New System.Drawing.Point(4, 4)
        Me.Botao2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Botao2.Name = "Botao2"
        Me.Botao2.Size = New System.Drawing.Size(60, 28)
        Me.Botao2.TabIndex = 18
        Me.Botao2.Text = "<"
        Me.Botao2.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(140, 0)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 17)
        Me.Label3.TabIndex = 19
        Me.Label3.Text = "0 de 0"
        '
        'FazerReserva
        '
        Me.FazerReserva.Location = New System.Drawing.Point(495, 109)
        Me.FazerReserva.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.FazerReserva.Name = "FazerReserva"
        Me.FazerReserva.Size = New System.Drawing.Size(116, 52)
        Me.FazerReserva.TabIndex = 28
        Me.FazerReserva.Text = "Fazer Reserva"
        Me.FazerReserva.UseVisualStyleBackColor = True
        '
        'Numero
        '
        Me.Numero.AutoSize = True
        Me.Numero.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Numero.Location = New System.Drawing.Point(4, 0)
        Me.Numero.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Numero.Name = "Numero"
        Me.Numero.Size = New System.Drawing.Size(182, 20)
        Me.Numero.TabIndex = 29
        Me.Numero.Text = "Restaurante Numero"
        '
        'DataReserva
        '
        Me.DataReserva.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DataReserva.Location = New System.Drawing.Point(131, 170)
        Me.DataReserva.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.DataReserva.Name = "DataReserva"
        Me.DataReserva.Size = New System.Drawing.Size(265, 22)
        Me.DataReserva.TabIndex = 30
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(4, 166)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(95, 17)
        Me.Label7.TabIndex = 31
        Me.Label7.Text = "Data Reserva"
        '
        'CustoTotal
        '
        Me.CustoTotal.Location = New System.Drawing.Point(482, 34)
        Me.CustoTotal.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CustoTotal.Name = "CustoTotal"
        Me.CustoTotal.Size = New System.Drawing.Size(316, 22)
        Me.CustoTotal.TabIndex = 34
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(373, 30)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(101, 17)
        Me.Label8.TabIndex = 35
        Me.Label8.Text = " Total Reserva"
        '
        'CheckedListBox1
        '
        Me.CheckedListBox1.FormattingEnabled = True
        Me.CheckedListBox1.Location = New System.Drawing.Point(745, 4)
        Me.CheckedListBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CheckedListBox1.Name = "CheckedListBox1"
        Me.CheckedListBox1.Size = New System.Drawing.Size(239, 310)
        Me.CheckedListBox1.TabIndex = 38
        '
        'CheckedListBox2
        '
        Me.CheckedListBox2.FormattingEnabled = True
        Me.CheckedListBox2.Location = New System.Drawing.Point(498, 4)
        Me.CheckedListBox2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CheckedListBox2.Name = "CheckedListBox2"
        Me.CheckedListBox2.Size = New System.Drawing.Size(239, 310)
        Me.CheckedListBox2.TabIndex = 39
        '
        'CheckedListBox3
        '
        Me.CheckedListBox3.FormattingEnabled = True
        Me.CheckedListBox3.Location = New System.Drawing.Point(251, 4)
        Me.CheckedListBox3.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CheckedListBox3.Name = "CheckedListBox3"
        Me.CheckedListBox3.Size = New System.Drawing.Size(239, 310)
        Me.CheckedListBox3.TabIndex = 40
        '
        'GridPratos
        '
        Me.GridPratos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.GridPratos.Location = New System.Drawing.Point(4, 24)
        Me.GridPratos.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GridPratos.Name = "GridPratos"
        Me.GridPratos.Size = New System.Drawing.Size(588, 225)
        Me.GridPratos.TabIndex = 41
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(98, 4)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(697, 22)
        Me.TextBox1.TabIndex = 42
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(4, 0)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(86, 17)
        Me.Label4.TabIndex = 43
        Me.Label4.Text = "Ingredientes"
        '
        'ReceitaTotal
        '
        Me.ReceitaTotal.Location = New System.Drawing.Point(104, 34)
        Me.ReceitaTotal.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.ReceitaTotal.Name = "ReceitaTotal"
        Me.ReceitaTotal.Size = New System.Drawing.Size(261, 22)
        Me.ReceitaTotal.TabIndex = 44
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(4, 30)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(92, 17)
        Me.Label5.TabIndex = 45
        Me.Label5.Text = "Receita Total"
        '
        'CheckedListBox4
        '
        Me.CheckedListBox4.FormattingEnabled = True
        Me.CheckedListBox4.Location = New System.Drawing.Point(4, 4)
        Me.CheckedListBox4.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CheckedListBox4.Name = "CheckedListBox4"
        Me.CheckedListBox4.Size = New System.Drawing.Size(239, 310)
        Me.CheckedListBox4.TabIndex = 46
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 3
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 127.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 364.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 19.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Nome, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.ProcurarCliente, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label1, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label7, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.NomeCliente, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.NIF, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.FazerReserva, 2, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.DataNascimento, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.DataReserva, 1, 3)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(37, 91)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 61.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 61.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 83.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(657, 203)
        Me.TableLayoutPanel1.TabIndex = 47
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckedListBox4)
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckedListBox3)
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckedListBox2)
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckedListBox1)
        Me.FlowLayoutPanel1.Controls.Add(Me.FlowLayoutPanel2)
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(37, 340)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(1010, 328)
        Me.FlowLayoutPanel1.TabIndex = 48
        '
        'FlowLayoutPanel2
        '
        Me.FlowLayoutPanel2.Location = New System.Drawing.Point(3, 321)
        Me.FlowLayoutPanel2.Name = "FlowLayoutPanel2"
        Me.FlowLayoutPanel2.Size = New System.Drawing.Size(200, 100)
        Me.FlowLayoutPanel2.TabIndex = 47
        '
        'FlowLayoutPanel3
        '
        Me.FlowLayoutPanel3.Controls.Add(Me.Numero)
        Me.FlowLayoutPanel3.Controls.Add(Me.GridPratos)
        Me.FlowLayoutPanel3.Location = New System.Drawing.Point(715, 49)
        Me.FlowLayoutPanel3.Name = "FlowLayoutPanel3"
        Me.FlowLayoutPanel3.Size = New System.Drawing.Size(620, 283)
        Me.FlowLayoutPanel3.TabIndex = 49
        '
        'FlowLayoutPanel4
        '
        Me.FlowLayoutPanel4.Controls.Add(Me.Label4)
        Me.FlowLayoutPanel4.Controls.Add(Me.TextBox1)
        Me.FlowLayoutPanel4.Controls.Add(Me.Label5)
        Me.FlowLayoutPanel4.Controls.Add(Me.ReceitaTotal)
        Me.FlowLayoutPanel4.Controls.Add(Me.Label8)
        Me.FlowLayoutPanel4.Controls.Add(Me.CustoTotal)
        Me.FlowLayoutPanel4.Location = New System.Drawing.Point(37, 681)
        Me.FlowLayoutPanel4.Name = "FlowLayoutPanel4"
        Me.FlowLayoutPanel4.Size = New System.Drawing.Size(807, 80)
        Me.FlowLayoutPanel4.TabIndex = 50
        '
        'FlowLayoutPanel5
        '
        Me.FlowLayoutPanel5.Controls.Add(Me.Botao2)
        Me.FlowLayoutPanel5.Controls.Add(Me.Botao1)
        Me.FlowLayoutPanel5.Controls.Add(Me.Label3)
        Me.FlowLayoutPanel5.Controls.Add(Me.Botao3)
        Me.FlowLayoutPanel5.Controls.Add(Me.Botao4)
        Me.FlowLayoutPanel5.Location = New System.Drawing.Point(37, 31)
        Me.FlowLayoutPanel5.Name = "FlowLayoutPanel5"
        Me.FlowLayoutPanel5.Size = New System.Drawing.Size(353, 38)
        Me.FlowLayoutPanel5.TabIndex = 51
        '
        'FormRestaurantes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1380, 773)
        Me.Controls.Add(Me.FlowLayoutPanel5)
        Me.Controls.Add(Me.FlowLayoutPanel4)
        Me.Controls.Add(Me.FlowLayoutPanel3)
        Me.Controls.Add(Me.FlowLayoutPanel1)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "FormRestaurantes"
        Me.Text = "FormRestaurantes"
        CType(Me.GridPratos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.FlowLayoutPanel3.ResumeLayout(False)
        Me.FlowLayoutPanel3.PerformLayout()
        Me.FlowLayoutPanel4.ResumeLayout(False)
        Me.FlowLayoutPanel4.PerformLayout()
        Me.FlowLayoutPanel5.ResumeLayout(False)
        Me.FlowLayoutPanel5.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents NomeCliente As TextBox
    Friend WithEvents NIF As TextBox
    Friend WithEvents DataNascimento As DateTimePicker
    Friend WithEvents Nome As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents ProcurarCliente As Button
    Friend WithEvents Botao4 As Button
    Friend WithEvents Botao3 As Button
    Friend WithEvents Botao1 As Button
    Friend WithEvents Botao2 As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents FazerReserva As Button
    Friend WithEvents Numero As Label
    Friend WithEvents DataReserva As DateTimePicker
    Friend WithEvents Label7 As Label
    Friend WithEvents CustoTotal As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents CheckedListBox1 As CheckedListBox
    Friend WithEvents CheckedListBox2 As CheckedListBox
    Friend WithEvents CheckedListBox3 As CheckedListBox
    Friend WithEvents GridPratos As DataGridView
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents ReceitaTotal As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents CheckedListBox4 As CheckedListBox
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents FlowLayoutPanel2 As FlowLayoutPanel
    Friend WithEvents FlowLayoutPanel3 As FlowLayoutPanel
    Friend WithEvents FlowLayoutPanel4 As FlowLayoutPanel
    Friend WithEvents FlowLayoutPanel5 As FlowLayoutPanel
End Class
