﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormIngredientes
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Nome = New System.Windows.Forms.TextBox()
        Me.Precoo = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Quantidadee = New System.Windows.Forms.TextBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.AdicionarRemover = New System.Windows.Forms.TextBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Ing = New System.Windows.Forms.Label()
        Me.GridIng = New System.Windows.Forms.DataGridView()
        Me.Numero = New System.Windows.Forms.TextBox()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        CType(Me.GridIng, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Nome
        '
        Me.Nome.Location = New System.Drawing.Point(112, 4)
        Me.Nome.Margin = New System.Windows.Forms.Padding(4)
        Me.Nome.Name = "Nome"
        Me.Nome.Size = New System.Drawing.Size(132, 22)
        Me.Nome.TabIndex = 0
        '
        'Precoo
        '
        Me.Precoo.Location = New System.Drawing.Point(112, 62)
        Me.Precoo.Margin = New System.Windows.Forms.Padding(4)
        Me.Precoo.Name = "Precoo"
        Me.Precoo.Size = New System.Drawing.Size(132, 22)
        Me.Precoo.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 0)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(45, 17)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Nome"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(4, 58)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 17)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Preço/unidade"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(4, 109)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(82, 17)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Quantidade"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(287, 4)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(120, 50)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "Criar Ingrediente"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(808, 4)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(120, 50)
        Me.Button2.TabIndex = 7
        Me.Button2.Text = "Adicionar Quantidade"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Quantidadee
        '
        Me.Quantidadee.Location = New System.Drawing.Point(112, 113)
        Me.Quantidadee.Margin = New System.Windows.Forms.Padding(4)
        Me.Quantidadee.Name = "Quantidadee"
        Me.Quantidadee.Size = New System.Drawing.Size(132, 22)
        Me.Quantidadee.TabIndex = 8
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(287, 113)
        Me.Button3.Margin = New System.Windows.Forms.Padding(4)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(120, 50)
        Me.Button3.TabIndex = 9
        Me.Button3.Text = "Remover Quantidade"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(550, 58)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(82, 17)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Quantidade"
        '
        'AdicionarRemover
        '
        Me.AdicionarRemover.Location = New System.Drawing.Point(644, 62)
        Me.AdicionarRemover.Margin = New System.Windows.Forms.Padding(4)
        Me.AdicionarRemover.Name = "AdicionarRemover"
        Me.AdicionarRemover.Size = New System.Drawing.Size(123, 22)
        Me.AdicionarRemover.TabIndex = 11
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(287, 62)
        Me.Button4.Margin = New System.Windows.Forms.Padding(4)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(120, 43)
        Me.Button4.TabIndex = 12
        Me.Button4.Text = "Registar ingrediente"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(264, 4)
        Me.Button6.Margin = New System.Windows.Forms.Padding(4)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(60, 28)
        Me.Button6.TabIndex = 14
        Me.Button6.Text = ">>"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(196, 4)
        Me.Button5.Margin = New System.Windows.Forms.Padding(4)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(60, 28)
        Me.Button5.TabIndex = 15
        Me.Button5.Text = ">"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(4, 4)
        Me.Button7.Margin = New System.Windows.Forms.Padding(4)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(60, 28)
        Me.Button7.TabIndex = 16
        Me.Button7.Text = "<<"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(72, 4)
        Me.Button8.Margin = New System.Windows.Forms.Padding(4)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(60, 28)
        Me.Button8.TabIndex = 17
        Me.Button8.Text = "<"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Ing
        '
        Me.Ing.AutoSize = True
        Me.Ing.Location = New System.Drawing.Point(140, 0)
        Me.Ing.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Ing.Name = "Ing"
        Me.Ing.Size = New System.Drawing.Size(48, 17)
        Me.Ing.TabIndex = 18
        Me.Ing.Text = "0 de 0"
        '
        'GridIng
        '
        Me.GridIng.AllowUserToAddRows = False
        Me.GridIng.AllowUserToDeleteRows = False
        Me.GridIng.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.GridIng.Location = New System.Drawing.Point(4, 4)
        Me.GridIng.Margin = New System.Windows.Forms.Padding(4)
        Me.GridIng.Name = "GridIng"
        Me.GridIng.ReadOnly = True
        Me.GridIng.Size = New System.Drawing.Size(476, 270)
        Me.GridIng.TabIndex = 27
        '
        'Numero
        '
        Me.Numero.Location = New System.Drawing.Point(610, 4)
        Me.Numero.Margin = New System.Windows.Forms.Padding(4)
        Me.Numero.Name = "Numero"
        Me.Numero.Size = New System.Drawing.Size(239, 22)
        Me.Numero.TabIndex = 74
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(857, 4)
        Me.Button10.Margin = New System.Windows.Forms.Padding(4)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(60, 28)
        Me.Button10.TabIndex = 75
        Me.Button10.Text = ">"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 9
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 286.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 9.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Button7, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Button8, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Ing, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Numero, 7, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Button6, 4, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Button11, 6, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Button10, 8, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Button5, 3, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(36, 12)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(940, 59)
        Me.TableLayoutPanel1.TabIndex = 77
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(550, 4)
        Me.Button11.Margin = New System.Windows.Forms.Padding(4)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(52, 28)
        Me.Button11.TabIndex = 76
        Me.Button11.Text = "<"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 6
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 175.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 263.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 94.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 164.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 174.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.Label1, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Label3, 0, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.Label2, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.Button1, 2, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Precoo, 1, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.Nome, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Quantidadee, 1, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.Button3, 2, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.Button4, 2, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.Label4, 3, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.AdicionarRemover, 4, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.Button9, 5, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.Button2, 5, 0)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(36, 89)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 2
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(940, 157)
        Me.TableLayoutPanel2.TabIndex = 78
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(808, 62)
        Me.Button9.Margin = New System.Windows.Forms.Padding(4)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(120, 29)
        Me.Button9.TabIndex = 22
        Me.Button9.Text = "Remover ingrediente"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Controls.Add(Me.GridIng)
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(300, 259)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(493, 284)
        Me.FlowLayoutPanel1.TabIndex = 79
        '
        'FormIngredientes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1037, 555)
        Me.Controls.Add(Me.FlowLayoutPanel1)
        Me.Controls.Add(Me.TableLayoutPanel2)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "FormIngredientes"
        Me.Text = "FormIngredientes"
        CType(Me.GridIng, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Nome As TextBox
    Friend WithEvents Precoo As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Quantidadee As TextBox
    Friend WithEvents Button3 As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents AdicionarRemover As TextBox
    Friend WithEvents Button4 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Ing As Label
    Friend WithEvents GridIng As DataGridView
    Friend WithEvents Numero As TextBox
    Friend WithEvents Button10 As Button
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents Button11 As Button
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents Button9 As Button
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
End Class
