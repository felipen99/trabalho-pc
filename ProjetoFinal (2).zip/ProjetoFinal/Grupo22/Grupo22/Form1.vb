﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim cliente As Cliente
        cliente = New Cliente(NomeClienteTB.Text, DateTimePicker1.Value, NIFCLiente.Text)
        Cadeia.Clientes.Add(cliente)
        Me.Close()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
