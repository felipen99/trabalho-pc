﻿Public Class FormRestaurante

    Private Sub FormRestaurante_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        mostra()
    End Sub


    Public Sub mostra()
        If Cadeia.Count > 0 Then
            If visivel2 < 0 Then
                visivel2 = 0
            ElseIf visivel2 > Cadeia.Count - 1 Then
                visivel2 = Cadeia.Count - 1
            End If
            If visivel2 = 0 Then
                Me.Button2.Enabled = False
                Me.Button6.Enabled = False
                Me.Button3.Enabled = True
                Me.Button4.Enabled = True
            ElseIf visivel2 = Cadeia.Count - 1 Then
                Me.Button2.Enabled = True
                Me.Button6.Enabled = True
                Me.Button3.Enabled = False
                Me.Button4.Enabled = False
            Else
                Me.Button2.Enabled = True
                Me.Button6.Enabled = True
                Me.Button3.Enabled = True
                Me.Button4.Enabled = True

            End If
            If visivel2 = 0 And Cadeia.Count = 1 Then
                Me.Button2.Enabled = False
                Me.Button3.Enabled = False
                Me.Button4.Enabled = False
                Me.Button6.Enabled = False
                Me.Button1.Visible = True
                Me.Button5.Visible = True


            End If
            Label3.Text = visivel2 + 1 & " de " & Cadeia.Count
            Capacidade.Text = Cadeia(visivel2).Capacidadeinicial
            NomeRestaurante.Text = Cadeia(visivel2).Nome

            Restaurantes.Items.Clear()
            For k = 0 To Cadeia.Count - 1
                Restaurantes.Items.Add(Cadeia(k).Nome)
            Next
        Else
            inicial()
        End If
    End Sub

    Public Sub inicial()
        Me.Button5.Visible = False
        Me.Button3.Enabled = False
        Me.Button4.Enabled = False
        Me.Button6.Enabled = False
        Me.Button1.Visible = False
        Me.Button2.Enabled = False
        Me.Label3.Text = "0 de 0"
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        visivel2 = visivel2 + 1
        mostra()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        visivel2 = visivel2 - 1
        mostra()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        visivel2 = 0
        mostra()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        visivel2 = Cadeia.Count - 1
        mostra()
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Dim restaurante As New Restaurante
        Cadeia.Add(restaurante)
        visivel2 = Cadeia.Count - 1
        mostra()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Cadeia(visivel2).Nome = NomeRestaurante.Text

        Cadeia(visivel2).Capacidadeinicial = Capacidade.Text
        Cadeia(visivel2).criar()
        mostra()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim resultado As Boolean = False
        Dim k As Integer = 0
        While k <= Cadeia.Count - 1 And Not resultado
            If Cadeia(k).Nome = NomeRestaurante.Text And Cadeia(k).Nome <> "" Then
                resultado = True
                Cadeia.RemoveAt(k)
                mostra()
            End If
        End While


        If Not resultado Then
            MsgBox("O Restaurante Não Existe")
        End If
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs)
        Cadeia.gravar()
    End Sub
End Class