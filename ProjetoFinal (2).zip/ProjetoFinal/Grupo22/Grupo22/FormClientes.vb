﻿Public Class FormClientes


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Cadeia.Clientes(visivel3).Nome = NomeClienteTB.Text
        Cadeia.Clientes(visivel3).NIF = NIFCLiente.Text
        Cadeia.Clientes(visivel3).DataNascimento = DateTimePicker1.Value
        mostra()

    End Sub

    Public Sub mostra()
        If Cadeia.Clientes.Count > 0 Then

            If visivel3 < 0 Then
                visivel3 = 0
            ElseIf visivel3 > Cadeia.Clientes.Count - 1 Then
                visivel3 = Cadeia.Clientes.Count - 1
            End If
            If visivel3 = 0 Then
                Me.Button4.Enabled = False
                Me.Button5.Enabled = False
                Me.Button3.Enabled = True
                Me.Button6.Enabled = True
            ElseIf visivel3 = Cadeia.Clientes.Count - 1 Then
                Me.Button3.Enabled = False
                Me.Button6.Enabled = False
                Me.Button5.Enabled = True
                Me.Button4.Enabled = True
            Else
                Me.Button5.Enabled = True
                Me.Button3.Enabled = True
                Me.Button4.Enabled = True
                Me.Button6.Enabled = True

            End If
            If visivel3 = 0 And Cadeia.Clientes.Count = 1 Then
                Me.Button5.Enabled = False
                Me.Button3.Enabled = False
                Me.Button4.Enabled = False
                Me.Button6.Enabled = False
                Me.Button1.Visible = True
                Me.Button2.Visible = True
                NomeClienteTB.Enabled = True
                DateTimePicker1.Enabled = True
                NIFCLiente.Enabled = True
            End If

            NomeClienteTB.Text = Cadeia.Clientes(visivel3).Nome
            NIFCLiente.Text = Cadeia.Clientes(visivel3).NIF
            DateTimePicker1.Value = Cadeia.Clientes(visivel3).DataNascimento

            ListaClientes.Items.Clear()
            For k = 0 To Cadeia.Clientes.Count - 1
                ListaClientes.Items.Add(Cadeia.Clientes(k).Nome)
            Next
            Label3.Text = visivel3 + 1 & " de " & Cadeia.Clientes.Count
        Else
            inicial()
        End If

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        visivel3 = 0
        mostra()

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        visivel3 = visivel3 - 1
        mostra()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        visivel3 = visivel3 + 1
        mostra()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        visivel3 = Cadeia.Clientes.Count - 1
        mostra()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim resultado As Boolean = False
        Dim k As Integer
        k = 0
        While k <= Cadeia.Clientes.Count - 1 And Not resultado
            If Cadeia.Clientes(k).Nome = NomeClienteTB.Text And Cadeia.Clientes(k).NIF = NIFCLiente.Text And Cadeia.Clientes(k).Nome <> "Nome" Then
                resultado = True
                Cadeia.Clientes.RemoveAt(k)
                mostra()
            End If
        End While




        If Not resultado Then
            MsgBox("O Cliente Não Existe")
        End If
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click

        Dim cliente As Cliente
        cliente = New Cliente
        Cadeia.Clientes.Add(cliente)
        visivel3 = Cadeia.Clientes.Count - 1
        Me.NomeClienteTB.Focus()
        mostra()
    End Sub

    Private Sub FormClientes_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        inicial()
        mostra()
    End Sub

    Public Sub inicial()
        Me.Button5.Enabled = False
        Me.Button3.Enabled = False
        Me.Button4.Enabled = False
        Me.Button6.Enabled = False
        Me.Button1.Visible = False
        Me.Button2.Visible = False
        NomeClienteTB.Enabled = False
        DateTimePicker1.Enabled = False
        NIFCLiente.Enabled = False
        ListaClientes.Items.Clear()
        Me.NIFCLiente.Text = ""
        Me.NomeClienteTB.Text = ""
        Me.Label3.Text = "0 de 0"
        If Cadeia.Clientes.Count > 0 Then
            NomeClienteTB.Enabled = True
            DateTimePicker1.Enabled = True
            NIFCLiente.Enabled = True
        End If

    End Sub

    Private Sub Nome_Click(sender As Object, e As EventArgs) Handles Nome.Click

    End Sub
End Class