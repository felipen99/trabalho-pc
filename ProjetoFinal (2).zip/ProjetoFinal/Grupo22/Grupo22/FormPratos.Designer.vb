﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormPratos
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.ListaPratos = New System.Windows.Forms.ListBox()
        Me.Lista = New System.Windows.Forms.CheckedListBox()
        Me.Botao4 = New System.Windows.Forms.Button()
        Me.Botao3 = New System.Windows.Forms.Button()
        Me.Botao2 = New System.Windows.Forms.Button()
        Me.Pratos = New System.Windows.Forms.Label()
        Me.NomePrato = New System.Windows.Forms.TextBox()
        Me.Preco = New System.Windows.Forms.TextBox()
        Me.Nome = New System.Windows.Forms.Label()
        Me.PrecoPrato = New System.Windows.Forms.Label()
        Me.Botao1 = New System.Windows.Forms.Button()
        Me.Entrada = New System.Windows.Forms.Button()
        Me.Sobremesa = New System.Windows.Forms.Button()
        Me.PratoPrincipal = New System.Windows.Forms.Button()
        Me.TipoPrato = New System.Windows.Forms.TextBox()
        Me.CriarPrato = New System.Windows.Forms.Button()
        Me.RegistarPrato = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ListaPratosDia = New System.Windows.Forms.ListBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.RegPratoDia = New System.Windows.Forms.Button()
        Me.NovoPrecoTB = New System.Windows.Forms.TextBox()
        Me.AlterarPreco = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.CriarPratoDia = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.PratoDias = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Numero = New System.Windows.Forms.TextBox()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ListaPratos
        '
        Me.ListaPratos.FormattingEnabled = True
        Me.ListaPratos.ItemHeight = 16
        Me.ListaPratos.Location = New System.Drawing.Point(232, 4)
        Me.ListaPratos.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.ListaPratos.Name = "ListaPratos"
        Me.ListaPratos.Size = New System.Drawing.Size(163, 596)
        Me.ListaPratos.TabIndex = 0
        '
        'Lista
        '
        Me.Lista.FormattingEnabled = True
        Me.Lista.Location = New System.Drawing.Point(4, 21)
        Me.Lista.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Lista.Name = "Lista"
        Me.Lista.Size = New System.Drawing.Size(522, 208)
        Me.Lista.TabIndex = 1
        '
        'Botao4
        '
        Me.Botao4.Location = New System.Drawing.Point(329, 15)
        Me.Botao4.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Botao4.Name = "Botao4"
        Me.Botao4.Size = New System.Drawing.Size(60, 28)
        Me.Botao4.TabIndex = 32
        Me.Botao4.Text = ">>"
        Me.Botao4.UseVisualStyleBackColor = True
        '
        'Botao3
        '
        Me.Botao3.Location = New System.Drawing.Point(253, 15)
        Me.Botao3.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Botao3.Name = "Botao3"
        Me.Botao3.Size = New System.Drawing.Size(60, 28)
        Me.Botao3.TabIndex = 33
        Me.Botao3.Text = ">"
        Me.Botao3.UseVisualStyleBackColor = True
        '
        'Botao2
        '
        Me.Botao2.Location = New System.Drawing.Point(128, 15)
        Me.Botao2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Botao2.Name = "Botao2"
        Me.Botao2.Size = New System.Drawing.Size(60, 28)
        Me.Botao2.TabIndex = 34
        Me.Botao2.Text = "<"
        Me.Botao2.UseVisualStyleBackColor = True
        '
        'Pratos
        '
        Me.Pratos.AutoSize = True
        Me.Pratos.Location = New System.Drawing.Point(196, 21)
        Me.Pratos.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Pratos.Name = "Pratos"
        Me.Pratos.Size = New System.Drawing.Size(48, 17)
        Me.Pratos.TabIndex = 35
        Me.Pratos.Text = "0 de 0"
        '
        'NomePrato
        '
        Me.NomePrato.Location = New System.Drawing.Point(114, 4)
        Me.NomePrato.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.NomePrato.Name = "NomePrato"
        Me.NomePrato.Size = New System.Drawing.Size(118, 22)
        Me.NomePrato.TabIndex = 36
        '
        'Preco
        '
        Me.Preco.Location = New System.Drawing.Point(114, 68)
        Me.Preco.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Preco.Name = "Preco"
        Me.Preco.Size = New System.Drawing.Size(132, 22)
        Me.Preco.TabIndex = 37
        '
        'Nome
        '
        Me.Nome.AutoSize = True
        Me.Nome.Location = New System.Drawing.Point(4, 0)
        Me.Nome.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Nome.Name = "Nome"
        Me.Nome.Size = New System.Drawing.Size(45, 17)
        Me.Nome.TabIndex = 38
        Me.Nome.Text = "Nome"
        '
        'PrecoPrato
        '
        Me.PrecoPrato.AutoSize = True
        Me.PrecoPrato.Location = New System.Drawing.Point(4, 64)
        Me.PrecoPrato.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.PrecoPrato.Name = "PrecoPrato"
        Me.PrecoPrato.Size = New System.Drawing.Size(45, 17)
        Me.PrecoPrato.TabIndex = 39
        Me.PrecoPrato.Text = "Preço"
        '
        'Botao1
        '
        Me.Botao1.Location = New System.Drawing.Point(57, 15)
        Me.Botao1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Botao1.Name = "Botao1"
        Me.Botao1.Size = New System.Drawing.Size(60, 28)
        Me.Botao1.TabIndex = 40
        Me.Botao1.Text = "<<"
        Me.Botao1.UseVisualStyleBackColor = True
        '
        'Entrada
        '
        Me.Entrada.Location = New System.Drawing.Point(4, 130)
        Me.Entrada.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Entrada.Name = "Entrada"
        Me.Entrada.Size = New System.Drawing.Size(102, 34)
        Me.Entrada.TabIndex = 41
        Me.Entrada.Text = "Entrada"
        Me.Entrada.UseVisualStyleBackColor = True
        '
        'Sobremesa
        '
        Me.Sobremesa.Location = New System.Drawing.Point(254, 130)
        Me.Sobremesa.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Sobremesa.Name = "Sobremesa"
        Me.Sobremesa.Size = New System.Drawing.Size(116, 33)
        Me.Sobremesa.TabIndex = 42
        Me.Sobremesa.Text = "Sobremesa"
        Me.Sobremesa.UseVisualStyleBackColor = True
        '
        'PratoPrincipal
        '
        Me.PratoPrincipal.Location = New System.Drawing.Point(114, 130)
        Me.PratoPrincipal.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.PratoPrincipal.Name = "PratoPrincipal"
        Me.PratoPrincipal.Size = New System.Drawing.Size(132, 33)
        Me.PratoPrincipal.TabIndex = 43
        Me.PratoPrincipal.Text = "PratoPrincipal"
        Me.PratoPrincipal.UseVisualStyleBackColor = True
        '
        'TipoPrato
        '
        Me.TipoPrato.Location = New System.Drawing.Point(114, 172)
        Me.TipoPrato.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TipoPrato.Name = "TipoPrato"
        Me.TipoPrato.Size = New System.Drawing.Size(132, 22)
        Me.TipoPrato.TabIndex = 44
        Me.TipoPrato.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'CriarPrato
        '
        Me.CriarPrato.Location = New System.Drawing.Point(378, 4)
        Me.CriarPrato.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CriarPrato.Name = "CriarPrato"
        Me.CriarPrato.Size = New System.Drawing.Size(124, 54)
        Me.CriarPrato.TabIndex = 45
        Me.CriarPrato.Text = "Criar Prato"
        Me.CriarPrato.UseVisualStyleBackColor = True
        '
        'RegistarPrato
        '
        Me.RegistarPrato.Location = New System.Drawing.Point(378, 68)
        Me.RegistarPrato.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.RegistarPrato.Name = "RegistarPrato"
        Me.RegistarPrato.Size = New System.Drawing.Size(124, 54)
        Me.RegistarPrato.TabIndex = 46
        Me.RegistarPrato.Text = "Registar Prato"
        Me.RegistarPrato.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 0)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(311, 17)
        Me.Label1.TabIndex = 47
        Me.Label1.Text = "Nome e Quantidade Respetiva dos Ingredientes"
        '
        'ListaPratosDia
        '
        Me.ListaPratosDia.FormattingEnabled = True
        Me.ListaPratosDia.ItemHeight = 16
        Me.ListaPratosDia.Location = New System.Drawing.Point(4, 4)
        Me.ListaPratosDia.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.ListaPratosDia.Name = "ListaPratosDia"
        Me.ListaPratosDia.Size = New System.Drawing.Size(163, 596)
        Me.ListaPratosDia.TabIndex = 48
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTimePicker1.Location = New System.Drawing.Point(111, 4)
        Me.DateTimePicker1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(141, 22)
        Me.DateTimePicker1.TabIndex = 49
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(4, 0)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(38, 17)
        Me.Label3.TabIndex = 59
        Me.Label3.Text = "Data"
        '
        'RegPratoDia
        '
        Me.RegPratoDia.Location = New System.Drawing.Point(486, 4)
        Me.RegPratoDia.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.RegPratoDia.Name = "RegPratoDia"
        Me.RegPratoDia.Size = New System.Drawing.Size(96, 55)
        Me.RegPratoDia.TabIndex = 62
        Me.RegPratoDia.Text = "Registar Prato do Dia"
        Me.RegPratoDia.UseVisualStyleBackColor = True
        '
        'NovoPrecoTB
        '
        Me.NovoPrecoTB.Location = New System.Drawing.Point(114, 235)
        Me.NovoPrecoTB.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.NovoPrecoTB.Name = "NovoPrecoTB"
        Me.NovoPrecoTB.Size = New System.Drawing.Size(132, 22)
        Me.NovoPrecoTB.TabIndex = 63
        '
        'AlterarPreco
        '
        Me.AlterarPreco.Location = New System.Drawing.Point(254, 235)
        Me.AlterarPreco.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.AlterarPreco.Name = "AlterarPreco"
        Me.AlterarPreco.Size = New System.Drawing.Size(116, 54)
        Me.AlterarPreco.TabIndex = 64
        Me.AlterarPreco.Text = "Alterar Preço"
        Me.AlterarPreco.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(4, 231)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(82, 17)
        Me.Label2.TabIndex = 65
        Me.Label2.Text = "Novo Preço"
        '
        'CriarPratoDia
        '
        Me.CriarPratoDia.Location = New System.Drawing.Point(375, 4)
        Me.CriarPratoDia.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CriarPratoDia.Name = "CriarPratoDia"
        Me.CriarPratoDia.Size = New System.Drawing.Size(103, 55)
        Me.CriarPratoDia.TabIndex = 66
        Me.CriarPratoDia.Text = "Criar Prato do Dia"
        Me.CriarPratoDia.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(57, 325)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(60, 28)
        Me.Button1.TabIndex = 67
        Me.Button1.Text = "<<"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(128, 325)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(60, 28)
        Me.Button2.TabIndex = 68
        Me.Button2.Text = "<"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'PratoDias
        '
        Me.PratoDias.AutoSize = True
        Me.PratoDias.Location = New System.Drawing.Point(196, 331)
        Me.PratoDias.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.PratoDias.Name = "PratoDias"
        Me.PratoDias.Size = New System.Drawing.Size(48, 17)
        Me.PratoDias.TabIndex = 69
        Me.PratoDias.Text = "0 de 0"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(253, 325)
        Me.Button3.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(60, 28)
        Me.Button3.TabIndex = 70
        Me.Button3.Text = ">"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(329, 325)
        Me.Button4.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(60, 28)
        Me.Button4.TabIndex = 71
        Me.Button4.Text = ">>"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(4, 4)
        Me.Button5.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(60, 28)
        Me.Button5.TabIndex = 72
        Me.Button5.Text = ">"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Numero
        '
        Me.Numero.Location = New System.Drawing.Point(72, 4)
        Me.Numero.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Numero.Name = "Numero"
        Me.Numero.Size = New System.Drawing.Size(254, 22)
        Me.Numero.TabIndex = 73
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(334, 4)
        Me.Button6.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(60, 28)
        Me.Button6.TabIndex = 74
        Me.Button6.Text = "<"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 3
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 175.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 53.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 196.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.ListaPratosDia, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.ListaPratos, 2, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(729, 84)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 9.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(403, 611)
        Me.TableLayoutPanel1.TabIndex = 75
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 3
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.Controls.Add(Me.Button5, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Button6, 2, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Numero, 1, 0)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(729, 21)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(403, 38)
        Me.TableLayoutPanel2.TabIndex = 76
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.ColumnCount = 4
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel3.Controls.Add(Me.Nome, 0, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.PrecoPrato, 0, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.NomePrato, 1, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.Preco, 1, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.Sobremesa, 2, 2)
        Me.TableLayoutPanel3.Controls.Add(Me.TipoPrato, 1, 3)
        Me.TableLayoutPanel3.Controls.Add(Me.NovoPrecoTB, 1, 4)
        Me.TableLayoutPanel3.Controls.Add(Me.Label2, 0, 4)
        Me.TableLayoutPanel3.Controls.Add(Me.CriarPrato, 3, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.RegistarPrato, 3, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.AlterarPreco, 2, 4)
        Me.TableLayoutPanel3.Controls.Add(Me.Entrada, 0, 2)
        Me.TableLayoutPanel3.Controls.Add(Me.PratoPrincipal, 1, 2)
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(57, 58)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 2
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 64.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 62.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 42.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 63.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 19.0!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(526, 295)
        Me.TableLayoutPanel3.TabIndex = 77
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.ColumnCount = 4
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 107.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 264.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 111.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 42.0!))
        Me.TableLayoutPanel4.Controls.Add(Me.Label3, 0, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.RegPratoDia, 3, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.CriarPratoDia, 2, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.DateTimePicker1, 1, 0)
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(57, 372)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 1
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(586, 81)
        Me.TableLayoutPanel4.TabIndex = 78
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Controls.Add(Me.Label1)
        Me.FlowLayoutPanel1.Controls.Add(Me.Lista)
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(57, 468)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(561, 247)
        Me.FlowLayoutPanel1.TabIndex = 79
        '
        'FormPratos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1191, 727)
        Me.Controls.Add(Me.FlowLayoutPanel1)
        Me.Controls.Add(Me.TableLayoutPanel4)
        Me.Controls.Add(Me.TableLayoutPanel3)
        Me.Controls.Add(Me.TableLayoutPanel2)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.PratoDias)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Botao1)
        Me.Controls.Add(Me.Pratos)
        Me.Controls.Add(Me.Botao2)
        Me.Controls.Add(Me.Botao3)
        Me.Controls.Add(Me.Botao4)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "FormPratos"
        Me.Text = "333"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.TableLayoutPanel3.PerformLayout()
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.TableLayoutPanel4.PerformLayout()
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.FlowLayoutPanel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ListaPratos As ListBox
    Friend WithEvents Lista As CheckedListBox
    Friend WithEvents Botao4 As Button
    Friend WithEvents Botao3 As Button
    Friend WithEvents Botao2 As Button
    Friend WithEvents Pratos As Label
    Friend WithEvents NomePrato As TextBox
    Friend WithEvents Preco As TextBox
    Friend WithEvents Nome As Label
    Friend WithEvents PrecoPrato As Label
    Friend WithEvents Botao1 As Button
    Friend WithEvents Entrada As Button
    Friend WithEvents Sobremesa As Button
    Friend WithEvents PratoPrincipal As Button
    Friend WithEvents TipoPrato As TextBox
    Friend WithEvents CriarPrato As Button
    Friend WithEvents RegistarPrato As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents ListaPratosDia As ListBox
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents Label3 As Label
    Friend WithEvents RegPratoDia As Button
    Friend WithEvents NovoPrecoTB As TextBox
    Friend WithEvents AlterarPreco As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents CriarPratoDia As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents PratoDias As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Numero As TextBox
    Friend WithEvents Button6 As Button
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel3 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel4 As TableLayoutPanel
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
End Class
