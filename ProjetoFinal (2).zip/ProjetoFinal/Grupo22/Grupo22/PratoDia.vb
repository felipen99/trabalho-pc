﻿Public Class PratoDia : Inherits Prato
    Private _data As Date

    Public Property Data As Date
        Get
            Return _data
        End Get
        Set(value As Date)
            _data = value
        End Set
    End Property
    Public Sub New()
        MyBase.New()
    End Sub
    Public Sub New(ByVal ingredintes As Ingredientes, ByVal Preco As Single,
                       ByVal Tipo As String, ByVal nome As String, ByVal data As Date, ByVal quantidades As ArrayList)
        MyBase.New(ingredintes, Preco, quantidades, Tipo, nome)

        Me.Data = data

    End Sub

    Public Overloads Function AlterarData(ByVal data As Date)
        Dim resultado As Boolean = False
        If data.Day > Me.Data.Day Then
            Me.Data = data
            resultado = True
        End If
        Return resultado
    End Function




End Class
