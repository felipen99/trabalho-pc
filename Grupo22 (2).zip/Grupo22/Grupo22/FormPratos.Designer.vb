﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormPratos
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.ListaPratos = New System.Windows.Forms.ListBox()
        Me.Lista = New System.Windows.Forms.CheckedListBox()
        Me.Numero = New System.Windows.Forms.Label()
        Me.Botao4 = New System.Windows.Forms.Button()
        Me.Botao3 = New System.Windows.Forms.Button()
        Me.Botao2 = New System.Windows.Forms.Button()
        Me.Pratos = New System.Windows.Forms.Label()
        Me.NomePrato = New System.Windows.Forms.TextBox()
        Me.Preco = New System.Windows.Forms.TextBox()
        Me.Nome = New System.Windows.Forms.Label()
        Me.PrecoPrato = New System.Windows.Forms.Label()
        Me.Botao1 = New System.Windows.Forms.Button()
        Me.Entrada = New System.Windows.Forms.Button()
        Me.Sobremesa = New System.Windows.Forms.Button()
        Me.PratoPrincipal = New System.Windows.Forms.Button()
        Me.TipoPrato = New System.Windows.Forms.TextBox()
        Me.CriarPrato = New System.Windows.Forms.Button()
        Me.RegistarPrato = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.AlterarPreco = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.NovoPrecoTB = New System.Windows.Forms.TextBox()
        Me.AlteraIng = New System.Windows.Forms.Button()
        Me.RegPratoDia = New System.Windows.Forms.Button()
        Me.HoraPratoDia = New System.Windows.Forms.TextBox()
        Me.Almoco = New System.Windows.Forms.Button()
        Me.Jantar = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.CriarPratoDia = New System.Windows.Forms.Button()
        Me.ListaPratosDia = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'ListaPratos
        '
        Me.ListaPratos.FormattingEnabled = True
        Me.ListaPratos.Location = New System.Drawing.Point(520, 63)
        Me.ListaPratos.Name = "ListaPratos"
        Me.ListaPratos.Size = New System.Drawing.Size(121, 433)
        Me.ListaPratos.TabIndex = 0
        '
        'Lista
        '
        Me.Lista.FormattingEnabled = True
        Me.Lista.Location = New System.Drawing.Point(31, 351)
        Me.Lista.Name = "Lista"
        Me.Lista.Size = New System.Drawing.Size(377, 139)
        Me.Lista.TabIndex = 1
        '
        'Numero
        '
        Me.Numero.AutoSize = True
        Me.Numero.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Numero.Location = New System.Drawing.Point(562, 26)
        Me.Numero.Name = "Numero"
        Me.Numero.Size = New System.Drawing.Size(150, 16)
        Me.Numero.TabIndex = 30
        Me.Numero.Text = "Restaurante Numero"
        '
        'Botao4
        '
        Me.Botao4.Location = New System.Drawing.Point(316, 7)
        Me.Botao4.Name = "Botao4"
        Me.Botao4.Size = New System.Drawing.Size(45, 23)
        Me.Botao4.TabIndex = 32
        Me.Botao4.Text = ">>"
        Me.Botao4.UseVisualStyleBackColor = True
        '
        'Botao3
        '
        Me.Botao3.Location = New System.Drawing.Point(265, 7)
        Me.Botao3.Name = "Botao3"
        Me.Botao3.Size = New System.Drawing.Size(45, 23)
        Me.Botao3.TabIndex = 33
        Me.Botao3.Text = ">"
        Me.Botao3.UseVisualStyleBackColor = True
        '
        'Botao2
        '
        Me.Botao2.Location = New System.Drawing.Point(160, 7)
        Me.Botao2.Name = "Botao2"
        Me.Botao2.Size = New System.Drawing.Size(45, 23)
        Me.Botao2.TabIndex = 34
        Me.Botao2.Text = "<"
        Me.Botao2.UseVisualStyleBackColor = True
        '
        'Pratos
        '
        Me.Pratos.AutoSize = True
        Me.Pratos.Location = New System.Drawing.Point(213, 12)
        Me.Pratos.Name = "Pratos"
        Me.Pratos.Size = New System.Drawing.Size(37, 13)
        Me.Pratos.TabIndex = 35
        Me.Pratos.Text = "0 de 0"
        '
        'NomePrato
        '
        Me.NomePrato.Location = New System.Drawing.Point(111, 48)
        Me.NomePrato.Name = "NomePrato"
        Me.NomePrato.Size = New System.Drawing.Size(100, 20)
        Me.NomePrato.TabIndex = 36
        '
        'Preco
        '
        Me.Preco.Location = New System.Drawing.Point(111, 85)
        Me.Preco.Name = "Preco"
        Me.Preco.Size = New System.Drawing.Size(100, 20)
        Me.Preco.TabIndex = 37
        '
        'Nome
        '
        Me.Nome.AutoSize = True
        Me.Nome.Location = New System.Drawing.Point(57, 51)
        Me.Nome.Name = "Nome"
        Me.Nome.Size = New System.Drawing.Size(35, 13)
        Me.Nome.TabIndex = 38
        Me.Nome.Text = "Nome"
        '
        'PrecoPrato
        '
        Me.PrecoPrato.AutoSize = True
        Me.PrecoPrato.Location = New System.Drawing.Point(57, 88)
        Me.PrecoPrato.Name = "PrecoPrato"
        Me.PrecoPrato.Size = New System.Drawing.Size(35, 13)
        Me.PrecoPrato.TabIndex = 39
        Me.PrecoPrato.Text = "Preço"
        '
        'Botao1
        '
        Me.Botao1.Location = New System.Drawing.Point(109, 7)
        Me.Botao1.Name = "Botao1"
        Me.Botao1.Size = New System.Drawing.Size(45, 23)
        Me.Botao1.TabIndex = 40
        Me.Botao1.Text = "<<"
        Me.Botao1.UseVisualStyleBackColor = True
        '
        'Entrada
        '
        Me.Entrada.Location = New System.Drawing.Point(21, 122)
        Me.Entrada.Name = "Entrada"
        Me.Entrada.Size = New System.Drawing.Size(87, 23)
        Me.Entrada.TabIndex = 41
        Me.Entrada.Text = "Entrada"
        Me.Entrada.UseVisualStyleBackColor = True
        '
        'Sobremesa
        '
        Me.Sobremesa.Location = New System.Drawing.Point(207, 122)
        Me.Sobremesa.Name = "Sobremesa"
        Me.Sobremesa.Size = New System.Drawing.Size(87, 23)
        Me.Sobremesa.TabIndex = 42
        Me.Sobremesa.Text = "Sobremesa"
        Me.Sobremesa.UseVisualStyleBackColor = True
        '
        'PratoPrincipal
        '
        Me.PratoPrincipal.Location = New System.Drawing.Point(114, 122)
        Me.PratoPrincipal.Name = "PratoPrincipal"
        Me.PratoPrincipal.Size = New System.Drawing.Size(87, 23)
        Me.PratoPrincipal.TabIndex = 43
        Me.PratoPrincipal.Text = "PratoPrincipal"
        Me.PratoPrincipal.UseVisualStyleBackColor = True
        '
        'TipoPrato
        '
        Me.TipoPrato.Location = New System.Drawing.Point(108, 155)
        Me.TipoPrato.Name = "TipoPrato"
        Me.TipoPrato.Size = New System.Drawing.Size(100, 20)
        Me.TipoPrato.TabIndex = 44
        Me.TipoPrato.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'CriarPrato
        '
        Me.CriarPrato.Location = New System.Drawing.Point(265, 51)
        Me.CriarPrato.Name = "CriarPrato"
        Me.CriarPrato.Size = New System.Drawing.Size(78, 41)
        Me.CriarPrato.TabIndex = 45
        Me.CriarPrato.Text = "Criar Prato"
        Me.CriarPrato.UseVisualStyleBackColor = True
        '
        'RegistarPrato
        '
        Me.RegistarPrato.Location = New System.Drawing.Point(325, 122)
        Me.RegistarPrato.Name = "RegistarPrato"
        Me.RegistarPrato.Size = New System.Drawing.Size(112, 41)
        Me.RegistarPrato.TabIndex = 46
        Me.RegistarPrato.Text = "Registar Prato"
        Me.RegistarPrato.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(31, 326)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(234, 13)
        Me.Label1.TabIndex = 47
        Me.Label1.Text = "Nome e Quantidade Respetiva dos Ingredientes"
        '
        'AlterarPreco
        '
        Me.AlterarPreco.Location = New System.Drawing.Point(325, 267)
        Me.AlterarPreco.Name = "AlterarPreco"
        Me.AlterarPreco.Size = New System.Drawing.Size(112, 41)
        Me.AlterarPreco.TabIndex = 48
        Me.AlterarPreco.Text = "Alterar Preço"
        Me.AlterarPreco.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(28, 285)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 13)
        Me.Label2.TabIndex = 50
        Me.Label2.Text = "Novo Preço"
        '
        'NovoPrecoTB
        '
        Me.NovoPrecoTB.Location = New System.Drawing.Point(111, 282)
        Me.NovoPrecoTB.Name = "NovoPrecoTB"
        Me.NovoPrecoTB.Size = New System.Drawing.Size(100, 20)
        Me.NovoPrecoTB.TabIndex = 49
        '
        'AlteraIng
        '
        Me.AlteraIng.Location = New System.Drawing.Point(160, 496)
        Me.AlteraIng.Name = "AlteraIng"
        Me.AlteraIng.Size = New System.Drawing.Size(112, 32)
        Me.AlteraIng.TabIndex = 51
        Me.AlteraIng.Text = "Alterar Ingredientes"
        Me.AlteraIng.UseVisualStyleBackColor = True
        '
        'RegPratoDia
        '
        Me.RegPratoDia.Location = New System.Drawing.Point(390, 197)
        Me.RegPratoDia.Name = "RegPratoDia"
        Me.RegPratoDia.Size = New System.Drawing.Size(112, 41)
        Me.RegPratoDia.TabIndex = 56
        Me.RegPratoDia.Text = "Registar como Prato do Dia"
        Me.RegPratoDia.UseVisualStyleBackColor = True
        '
        'HoraPratoDia
        '
        Me.HoraPratoDia.Location = New System.Drawing.Point(225, 226)
        Me.HoraPratoDia.Name = "HoraPratoDia"
        Me.HoraPratoDia.Size = New System.Drawing.Size(100, 20)
        Me.HoraPratoDia.TabIndex = 55
        Me.HoraPratoDia.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Almoco
        '
        Me.Almoco.Location = New System.Drawing.Point(185, 197)
        Me.Almoco.Name = "Almoco"
        Me.Almoco.Size = New System.Drawing.Size(87, 23)
        Me.Almoco.TabIndex = 54
        Me.Almoco.Text = "Almoço"
        Me.Almoco.UseVisualStyleBackColor = True
        '
        'Jantar
        '
        Me.Jantar.Location = New System.Drawing.Point(278, 197)
        Me.Jantar.Name = "Jantar"
        Me.Jantar.Size = New System.Drawing.Size(87, 23)
        Me.Jantar.TabIndex = 53
        Me.Jantar.Text = "Jantar"
        Me.Jantar.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(43, 229)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(30, 13)
        Me.Label3.TabIndex = 58
        Me.Label3.Text = "Data"
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTimePicker1.Location = New System.Drawing.Point(79, 226)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(94, 20)
        Me.DateTimePicker1.TabIndex = 59
        '
        'CriarPratoDia
        '
        Me.CriarPratoDia.Location = New System.Drawing.Point(359, 51)
        Me.CriarPratoDia.Name = "CriarPratoDia"
        Me.CriarPratoDia.Size = New System.Drawing.Size(78, 41)
        Me.CriarPratoDia.TabIndex = 60
        Me.CriarPratoDia.Text = "Criar Prato do Dia"
        Me.CriarPratoDia.UseVisualStyleBackColor = True
        '
        'ListaPratosDia
        '
        Me.ListaPratosDia.FormattingEnabled = True
        Me.ListaPratosDia.Location = New System.Drawing.Point(647, 63)
        Me.ListaPratosDia.Name = "ListaPratosDia"
        Me.ListaPratosDia.Size = New System.Drawing.Size(121, 433)
        Me.ListaPratosDia.TabIndex = 61
        '
        'FormPratos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 540)
        Me.Controls.Add(Me.ListaPratosDia)
        Me.Controls.Add(Me.CriarPratoDia)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.RegPratoDia)
        Me.Controls.Add(Me.HoraPratoDia)
        Me.Controls.Add(Me.Almoco)
        Me.Controls.Add(Me.Jantar)
        Me.Controls.Add(Me.AlteraIng)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.NovoPrecoTB)
        Me.Controls.Add(Me.AlterarPreco)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.RegistarPrato)
        Me.Controls.Add(Me.CriarPrato)
        Me.Controls.Add(Me.TipoPrato)
        Me.Controls.Add(Me.PratoPrincipal)
        Me.Controls.Add(Me.Sobremesa)
        Me.Controls.Add(Me.Entrada)
        Me.Controls.Add(Me.Botao1)
        Me.Controls.Add(Me.PrecoPrato)
        Me.Controls.Add(Me.Nome)
        Me.Controls.Add(Me.Preco)
        Me.Controls.Add(Me.NomePrato)
        Me.Controls.Add(Me.Pratos)
        Me.Controls.Add(Me.Botao2)
        Me.Controls.Add(Me.Botao3)
        Me.Controls.Add(Me.Botao4)
        Me.Controls.Add(Me.Numero)
        Me.Controls.Add(Me.Lista)
        Me.Controls.Add(Me.ListaPratos)
        Me.Name = "FormPratos"
        Me.Text = "FormPratos"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ListaPratos As ListBox
    Friend WithEvents Lista As CheckedListBox
    Friend WithEvents Numero As Label
    Friend WithEvents Botao4 As Button
    Friend WithEvents Botao3 As Button
    Friend WithEvents Botao2 As Button
    Friend WithEvents Pratos As Label
    Friend WithEvents NomePrato As TextBox
    Friend WithEvents Preco As TextBox
    Friend WithEvents Nome As Label
    Friend WithEvents PrecoPrato As Label
    Friend WithEvents Botao1 As Button
    Friend WithEvents Entrada As Button
    Friend WithEvents Sobremesa As Button
    Friend WithEvents PratoPrincipal As Button
    Friend WithEvents TipoPrato As TextBox
    Friend WithEvents CriarPrato As Button
    Friend WithEvents RegistarPrato As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents AlterarPreco As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents NovoPrecoTB As TextBox
    Friend WithEvents AlteraIng As Button
    Friend WithEvents RegPratoDia As Button
    Friend WithEvents HoraPratoDia As TextBox
    Friend WithEvents Almoco As Button
    Friend WithEvents Jantar As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents CriarPratoDia As Button
    Friend WithEvents ListaPratosDia As ListBox
End Class
