﻿Module VarGlobal
    Public Cadeia As Restaurantes
    Public visivel2 As Integer
    Public restaurante As New Restaurante
    Public visivel3 As Integer
    Public Sub initvars()
        Cadeia = New Restaurantes
        Cadeia.Add(restaurante)
        visivel2 = 0
        visivel3 = 0
    End Sub
End Module
