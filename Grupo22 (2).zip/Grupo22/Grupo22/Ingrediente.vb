﻿Public Class Ingrediente
    Private _nome As String = "Ingrediente"
    Private _quantidade1 As Single = 0
    Private _custouni1 As Single = 0

    Public Property Nome As String
        Get
            Return _nome
        End Get
        Set(value As String)
            _nome = value
        End Set
    End Property

    Public Property Quantidade As Single
        Get
            Return _quantidade1
        End Get
        Set(value As Single)
            _quantidade1 = value
        End Set
    End Property

    Public Property Custouni As Single
        Get
            Return _custouni1
        End Get
        Set(value As Single)
            _custouni1 = value
        End Set
    End Property

    Public Sub New()

    End Sub
    Public Sub New(ByVal nome As String, ByVal quantidade As Integer, ByVal custo As Integer)
        Me.Custouni = custo
        Me.Nome = nome
        Me.Quantidade = quantidade
    End Sub

    Public Function adicionar(ByVal quant As String)
        Dim resultado As Boolean = False
        If quant > 0 Then
            Me.Quantidade = Me.Quantidade + quant
            resultado = True
        End If
        Return resultado
    End Function

    Public Function remover(ByVal quant As Integer)
        Dim resultado As Boolean = False
        If quant < 0 Then
            Me.Quantidade = Me.Quantidade + quant
            resultado = True
        End If
        Return resultado
    End Function
End Class
